package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.StudentDatabase
import com.example.data.local.StudyBlockEntity
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var db: StudentDatabase

  @Before
  fun setUp() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db =
      Room.inMemoryDatabaseBuilder(context, StudentDatabase::class.java)
        .allowMainThreadQueries()
        .build()
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `app name matches Student Tasks`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Student Tasks", appName)
  }

  @Test
  fun `task CRUD and completion persist in Room`() = runTest {
    val dao = db.taskDao()
    val id =
      dao.insertTask(
        TaskEntity(
          title = "Operating Systems Lab",
          course = "CS 401",
          category = TaskCategory.ASSIGNMENT,
          priority = TaskPriority.HIGH,
          dueDateMillis = System.currentTimeMillis() + 86_400_000L,
        )
      )

    var tasks = dao.observeAllTasks().first()
    assertEquals(1, tasks.size)
    assertEquals("Operating Systems Lab", tasks.first().title)

    dao.updateTask(tasks.first().copy(isCompleted = true))
    tasks = dao.observeAllTasks().first()
    assertTrue(tasks.first().isCompleted)

    dao.deleteTaskById(id)
    tasks = dao.observeAllTasks().first()
    assertTrue(tasks.isEmpty())
  }

  @Test
  fun `study timetable block CRUD persists in Room`() = runTest {
    val blockDao = db.studyBlockDao()
    val id =
      blockDao.insertBlock(
        StudyBlockEntity(
          title = "Algorithms Review",
          course = "CS 301",
          dayOfWeek = 1,
          startMinutesFromMidnight = 540,
          endMinutesFromMidnight = 630,
          location = "Library",
        )
      )

    val blocks = blockDao.observeAllBlocks().first()
    assertEquals(1, blocks.size)
    assertEquals("Algorithms Review", blocks.first().title)

    blockDao.deleteBlockById(id)
    assertTrue(blockDao.observeAllBlocks().first().isEmpty())
  }
}
