package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studentDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "student_prefs")

enum class ThemePreference(val label: String) {
  SYSTEM("System"),
  LIGHT("Light"),
  DARK("Dark"),
}

data class StudentProfile(
  val isLoggedIn: Boolean = false,
  val name: String = "",
  val email: String = "",
  val major: String = "Computer Science",
  val academicYear: String = "Junior · Year 3",
  val dailyGoalMinutes: Int = 180,
  val themePreference: ThemePreference = ThemePreference.LIGHT,
  val hasSeededInitialData: Boolean = false,
)

class StudentPreferencesRepository(private val context: Context) {
  private object Keys {
    val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
    val STUDENT_NAME = stringPreferencesKey("student_name")
    val STUDENT_EMAIL = stringPreferencesKey("student_email")
    val STUDENT_MAJOR = stringPreferencesKey("student_major")
    val ACADEMIC_YEAR = stringPreferencesKey("academic_year")
    val DAILY_GOAL_MINUTES = intPreferencesKey("daily_goal_minutes")
    val THEME_PREFERENCE = stringPreferencesKey("theme_preference")
    val HAS_SEEDED_INITIAL_DATA = booleanPreferencesKey("has_seeded_initial_data")
  }

  val profileFlow: Flow<StudentProfile> =
    context.studentDataStore.data.map { prefs ->
      val themeStr = prefs[Keys.THEME_PREFERENCE] ?: ThemePreference.LIGHT.name
      StudentProfile(
        isLoggedIn = prefs[Keys.IS_LOGGED_IN] ?: false,
        name = prefs[Keys.STUDENT_NAME] ?: "",
        email = prefs[Keys.STUDENT_EMAIL] ?: "",
        major = prefs[Keys.STUDENT_MAJOR] ?: "Computer Science",
        academicYear = prefs[Keys.ACADEMIC_YEAR] ?: "Junior · Year 3",
        dailyGoalMinutes = prefs[Keys.DAILY_GOAL_MINUTES] ?: 180,
        themePreference =
          runCatching { ThemePreference.valueOf(themeStr) }.getOrDefault(ThemePreference.LIGHT),
        hasSeededInitialData = prefs[Keys.HAS_SEEDED_INITIAL_DATA] ?: false,
      )
    }

  suspend fun signInStudent(
    name: String,
    email: String,
    major: String,
    academicYear: String,
  ) {
    context.studentDataStore.edit { prefs ->
      prefs[Keys.IS_LOGGED_IN] = true
      prefs[Keys.STUDENT_NAME] = name.trim().ifEmpty { "Maya Lin" }
      prefs[Keys.STUDENT_EMAIL] = email.trim().ifEmpty { "maya.lin@university.edu" }
      prefs[Keys.STUDENT_MAJOR] = major.trim().ifEmpty { "Computer Science" }
      prefs[Keys.ACADEMIC_YEAR] = academicYear.trim().ifEmpty { "Junior · Year 3" }
    }
  }

  suspend fun updateProfile(
    name: String,
    email: String,
    major: String,
    academicYear: String,
    dailyGoalMinutes: Int,
  ) {
    context.studentDataStore.edit { prefs ->
      prefs[Keys.STUDENT_NAME] = name.trim()
      prefs[Keys.STUDENT_EMAIL] = email.trim()
      prefs[Keys.STUDENT_MAJOR] = major.trim()
      prefs[Keys.ACADEMIC_YEAR] = academicYear.trim()
      prefs[Keys.DAILY_GOAL_MINUTES] = dailyGoalMinutes.coerceIn(30, 600)
    }
  }

  suspend fun setDailyGoalMinutes(minutes: Int) {
    context.studentDataStore.edit { prefs ->
      prefs[Keys.DAILY_GOAL_MINUTES] = minutes.coerceIn(30, 600)
    }
  }

  suspend fun setThemePreference(theme: ThemePreference) {
    context.studentDataStore.edit { prefs -> prefs[Keys.THEME_PREFERENCE] = theme.name }
  }

  suspend fun markSeeded() {
    context.studentDataStore.edit { prefs -> prefs[Keys.HAS_SEEDED_INITIAL_DATA] = true }
  }

  suspend fun signOut() {
    context.studentDataStore.edit { prefs -> prefs[Keys.IS_LOGGED_IN] = false }
  }
}
