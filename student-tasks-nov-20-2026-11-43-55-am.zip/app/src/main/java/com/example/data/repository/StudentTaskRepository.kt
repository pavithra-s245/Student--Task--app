package com.example.data.repository

import com.example.data.local.StudentPreferencesRepository
import com.example.data.local.StudentProfile
import com.example.data.local.StudyBlockDao
import com.example.data.local.StudyBlockEntity
import com.example.data.local.StudySessionDao
import com.example.data.local.StudySessionEntity
import com.example.data.local.TaskCategory
import com.example.data.local.TaskDao
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.data.local.ThemePreference
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class StudentTaskRepository(
  private val taskDao: TaskDao,
  private val studyBlockDao: StudyBlockDao,
  private val studySessionDao: StudySessionDao,
  private val preferencesRepository: StudentPreferencesRepository,
) {
  val allTasks: Flow<List<TaskEntity>> = taskDao.observeAllTasks()
  val allStudyBlocks: Flow<List<StudyBlockEntity>> = studyBlockDao.observeAllBlocks()
  val recentStudySessions: Flow<List<StudySessionEntity>> = studySessionDao.observeRecentSessions()
  val studentProfile: Flow<StudentProfile> = preferencesRepository.profileFlow

  suspend fun ensureInitialDataSeeded() {
    val profile = preferencesRepository.profileFlow.first()
    if (!profile.hasSeededInitialData && taskDao.countTasks() == 0 && studyBlockDao.countBlocks() == 0) {
      seedStarterSemesterData()
      preferencesRepository.markSeeded()
    }
  }

  suspend fun resetStarterSampleData() {
    taskDao.clearAllTasks()
    studyBlockDao.clearAllBlocks()
    studySessionDao.clearAllSessions()
    seedStarterSemesterData()
    preferencesRepository.markSeeded()
  }

  suspend fun saveTask(task: TaskEntity): Long = taskDao.insertTask(task)

  suspend fun toggleTaskCompletion(task: TaskEntity) {
    val nowCompleted = !task.isCompleted
    taskDao.updateTask(
      task.copy(
        isCompleted = nowCompleted,
        completedAtMillis = if (nowCompleted) System.currentTimeMillis() else null,
      )
    )
    if (nowCompleted) {
      logStudyMinutes(minutes = (task.estimatedMinutes / 2).coerceIn(15, 60))
    }
  }

  suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

  suspend fun clearCompletedTasks() = taskDao.deleteCompletedTasks()

  suspend fun saveStudyBlock(block: StudyBlockEntity): Long = studyBlockDao.insertBlock(block)

  suspend fun toggleStudyBlockCompletion(block: StudyBlockEntity) {
    val nowCompleted = !block.isCompleted
    studyBlockDao.updateBlock(block.copy(isCompleted = nowCompleted))
    if (nowCompleted) {
      val duration = (block.endMinutesFromMidnight - block.startMinutesFromMidnight).coerceIn(15, 180)
      logStudyMinutes(duration)
    }
  }

  suspend fun deleteStudyBlock(blockId: Long) = studyBlockDao.deleteBlockById(blockId)

  suspend fun logStudyMinutes(minutes: Int) {
    val cal = Calendar.getInstance()
    val dayKey = formatDayKey(cal)
    val startOfDay = startOfDayMillis(cal)
    val existing = studySessionDao.getSessionForDay(dayKey)
    val updatedMinutes = ((existing?.minutesStudied ?: 0) + minutes).coerceAtLeast(0)
    studySessionDao.upsertSession(
      StudySessionEntity(
        dayKey = dayKey,
        epochDayMillis = startOfDay,
        minutesStudied = updatedMinutes,
      )
    )
  }

  suspend fun signInStudent(name: String, email: String, major: String, academicYear: String) {
    preferencesRepository.signInStudent(name, email, major, academicYear)
    ensureInitialDataSeeded()
  }

  suspend fun updateProfile(
    name: String,
    email: String,
    major: String,
    academicYear: String,
    dailyGoalMinutes: Int,
  ) = preferencesRepository.updateProfile(name, email, major, academicYear, dailyGoalMinutes)

  suspend fun setDailyGoalMinutes(minutes: Int) = preferencesRepository.setDailyGoalMinutes(minutes)

  suspend fun setThemePreference(theme: ThemePreference) = preferencesRepository.setThemePreference(theme)

  suspend fun signOut() = preferencesRepository.signOut()

  private suspend fun seedStarterSemesterData() {
    fun dueAt(daysFromToday: Int, hour: Int, minute: Int = 59): Long {
      return Calendar.getInstance()
        .apply {
          add(Calendar.DAY_OF_YEAR, daysFromToday)
          set(Calendar.HOUR_OF_DAY, hour)
          set(Calendar.MINUTE, minute)
          set(Calendar.SECOND, 0)
          set(Calendar.MILLISECOND, 0)
        }
        .timeInMillis
    }

    val starterTasks =
      listOf(
        TaskEntity(
          title = "Graph Algorithms Problem Set #4",
          course = "CS 301",
          category = TaskCategory.ASSIGNMENT,
          priority = TaskPriority.HIGH,
          dueDateMillis = dueAt(0, 23, 59),
          estimatedMinutes = 90,
          notes = "Implement Dijkstra & Bellman-Ford shortest path proofs and submit PDF.",
          isCompleted = false,
        ),
        TaskEntity(
          title = "Cognitive Psychology Literature Review",
          course = "PSYC 215",
          category = TaskCategory.ASSIGNMENT,
          priority = TaskPriority.HIGH,
          dueDateMillis = dueAt(1, 17, 0),
          estimatedMinutes = 75,
          notes = "Synthesize 5 peer-reviewed papers on working memory consolidation.",
          isCompleted = false,
        ),
        TaskEntity(
          title = "Linear Algebra Midterm Practice Quiz",
          course = "MATH 240",
          category = TaskCategory.EXAM,
          priority = TaskPriority.HIGH,
          dueDateMillis = dueAt(2, 14, 0),
          estimatedMinutes = 60,
          notes = "Focus on eigenvalues, diagonalization, and orthogonal projections.",
          isCompleted = false,
        ),
        TaskEntity(
          title = "UX Capstone Wireframe Prototype",
          course = "DES 310",
          category = TaskCategory.PROJECT,
          priority = TaskPriority.MEDIUM,
          dueDateMillis = dueAt(4, 23, 59),
          estimatedMinutes = 120,
          notes = "Prepare interactive mobile flow for Friday studio critique.",
          isCompleted = false,
        ),
        TaskEntity(
          title = "Read Chapter 7: Neural Plasticity",
          course = "PSYC 215",
          category = TaskCategory.READING,
          priority = TaskPriority.LOW,
          dueDateMillis = dueAt(3, 12, 0),
          estimatedMinutes = 35,
          notes = "Highlight key diagrams before Thursday seminar.",
          isCompleted = false,
        ),
        TaskEntity(
          title = "Database Normalization Lab Report",
          course = "CS 301",
          category = TaskCategory.ASSIGNMENT,
          priority = TaskPriority.MEDIUM,
          dueDateMillis = dueAt(-1, 23, 59),
          estimatedMinutes = 50,
          notes = "Completed 3NF and BCNF schema diagrams.",
          isCompleted = true,
          completedAtMillis = System.currentTimeMillis() - 86_400_000L,
        ),
      )
    taskDao.insertTasks(starterTasks)

    val starterBlocks =
      listOf(
        // Monday (1)
        StudyBlockEntity(
          title = "Algorithms Deep Work",
          course = "CS 301",
          dayOfWeek = 1,
          startMinutesFromMidnight = 9 * 60,
          endMinutesFromMidnight = 10 * 60 + 30,
          location = "Science Library · Floor 3",
          colorTag = 0,
        ),
        StudyBlockEntity(
          title = "Linear Algebra Problem Drill",
          course = "MATH 240",
          dayOfWeek = 1,
          startMinutesFromMidnight = 13 * 60 + 30,
          endMinutesFromMidnight = 15 * 60,
          location = "Euler Hall 204",
          colorTag = 1,
        ),
        StudyBlockEntity(
          title = "Psychology Reading Notes",
          course = "PSYC 215",
          dayOfWeek = 1,
          startMinutesFromMidnight = 16 * 60,
          endMinutesFromMidnight = 17 * 60,
          location = "Campus Café",
          colorTag = 2,
        ),
        // Tuesday (2)
        StudyBlockEntity(
          title = "UX Studio Prototype Sprint",
          course = "DES 310",
          dayOfWeek = 2,
          startMinutesFromMidnight = 10 * 60,
          endMinutesFromMidnight = 11 * 60 + 45,
          location = "Design Lab B",
          colorTag = 1,
        ),
        StudyBlockEntity(
          title = "CS 301 Lab Prep",
          course = "CS 301",
          dayOfWeek = 2,
          startMinutesFromMidnight = 14 * 60,
          endMinutesFromMidnight = 15 * 60 + 30,
          location = "Engineering Commons",
          colorTag = 0,
        ),
        // Wednesday (3)
        StudyBlockEntity(
          title = "Midterm Review Session",
          course = "MATH 240",
          dayOfWeek = 3,
          startMinutesFromMidnight = 9 * 60 + 30,
          endMinutesFromMidnight = 11 * 60,
          location = "Quiet Reading Room",
          colorTag = 0,
        ),
        StudyBlockEntity(
          title = "Lit Review Synthesis",
          course = "PSYC 215",
          dayOfWeek = 3,
          startMinutesFromMidnight = 15 * 60,
          endMinutesFromMidnight = 16 * 60 + 30,
          location = "Main Library",
          colorTag = 1,
        ),
        // Thursday (4)
        StudyBlockEntity(
          title = "Graph Proofs & Practice",
          course = "CS 301",
          dayOfWeek = 4,
          startMinutesFromMidnight = 10 * 60,
          endMinutesFromMidnight = 11 * 60 + 30,
          location = "Science Library",
          colorTag = 0,
        ),
        StudyBlockEntity(
          title = "Seminar Discussion Prep",
          course = "PSYC 215",
          dayOfWeek = 4,
          startMinutesFromMidnight = 14 * 60,
          endMinutesFromMidnight = 15 * 60,
          location = "Humanities 112",
          colorTag = 2,
        ),
        // Friday (5)
        StudyBlockEntity(
          title = "Capstone Critique Rehearsal",
          course = "DES 310",
          dayOfWeek = 5,
          startMinutesFromMidnight = 11 * 60,
          endMinutesFromMidnight = 12 * 60 + 30,
          location = "Design Studio",
          colorTag = 1,
        ),
        StudyBlockEntity(
          title = "Weekly Flashcard Recap",
          course = "MATH 240",
          dayOfWeek = 5,
          startMinutesFromMidnight = 15 * 60,
          endMinutesFromMidnight = 16 * 60,
          location = "Dorm Study Lounge",
          colorTag = 3,
        ),
        // Saturday (6)
        StudyBlockEntity(
          title = "Weekend Assignment Catch-up",
          course = "CS 301",
          dayOfWeek = 6,
          startMinutesFromMidnight = 10 * 60 + 30,
          endMinutesFromMidnight = 12 * 60,
          location = "Home Desk",
          colorTag = 0,
        ),
        // Sunday (7)
        StudyBlockEntity(
          title = "Week Ahead Planning & Preview",
          course = "All Courses",
          dayOfWeek = 7,
          startMinutesFromMidnight = 17 * 60,
          endMinutesFromMidnight = 18 * 60,
          location = "Home Desk",
          colorTag = 1,
        ),
      )
    studyBlockDao.insertBlocks(starterBlocks)

    // Seed last 7 days of study progress so Study Progress Dashboard chart is populated immediately
    val sampleMinutes = listOf(120, 165, 95, 190, 140, 110, 85)
    val sessions =
      (6 downTo 0).mapIndexed { idx, daysAgo ->
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
        StudySessionEntity(
          dayKey = formatDayKey(cal),
          epochDayMillis = startOfDayMillis(cal),
          minutesStudied = sampleMinutes[idx],
        )
      }
    studySessionDao.upsertSessions(sessions)
  }

  companion object {
    fun formatDayKey(cal: Calendar): String {
      val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
      return sdf.format(cal.time)
    }

    fun startOfDayMillis(cal: Calendar): Long {
      val copy = cal.clone() as Calendar
      copy.set(Calendar.HOUR_OF_DAY, 0)
      copy.set(Calendar.MINUTE, 0)
      copy.set(Calendar.SECOND, 0)
      copy.set(Calendar.MILLISECOND, 0)
      return copy.timeInMillis
    }
  }
}
