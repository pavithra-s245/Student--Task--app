package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskCategory(val label: String) {
  ASSIGNMENT("Assignment"),
  EXAM("Exam"),
  PROJECT("Project"),
  READING("Reading"),
  GENERAL("Task"),
}

enum class TaskPriority(val label: String, val weight: Int) {
  HIGH("High", 3),
  MEDIUM("Medium", 2),
  LOW("Low", 1),
}

@Entity(tableName = "tasks")
data class TaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val course: String,
  val category: TaskCategory = TaskCategory.ASSIGNMENT,
  val priority: TaskPriority = TaskPriority.MEDIUM,
  val dueDateMillis: Long,
  val estimatedMinutes: Int = 45,
  val notes: String = "",
  val isCompleted: Boolean = false,
  val completedAtMillis: Long? = null,
  val createdAtMillis: Long = System.currentTimeMillis(),
)
