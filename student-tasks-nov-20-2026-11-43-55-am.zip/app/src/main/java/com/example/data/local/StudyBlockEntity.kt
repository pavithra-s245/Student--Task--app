package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a scheduled study block in the daily study timetable.
 * [dayOfWeek] uses 1 = Monday through 7 = Sunday.
 */
@Entity(tableName = "study_blocks")
data class StudyBlockEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val course: String,
  val dayOfWeek: Int,
  val startMinutesFromMidnight: Int,
  val endMinutesFromMidnight: Int,
  val location: String = "Campus Library",
  val colorTag: Int = 0, // 0 = Purple, 1 = Pastel Pink, 2 = Orchid, 3 = Lavender
  val isCompleted: Boolean = false,
)

/**
 * Tracks logged study minutes per calendar day (yyyy-MM-dd) for the Study Progress Dashboard.
 */
@Entity(tableName = "study_sessions")
data class StudySessionEntity(
  @PrimaryKey val dayKey: String,
  val epochDayMillis: Long,
  val minutesStudied: Int,
)
