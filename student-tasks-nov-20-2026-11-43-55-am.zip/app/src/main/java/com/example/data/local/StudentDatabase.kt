package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class StudentTypeConverters {
  @TypeConverter
  fun fromCategory(value: TaskCategory): String = value.name

  @TypeConverter
  fun toCategory(value: String): TaskCategory =
    runCatching { TaskCategory.valueOf(value) }.getOrDefault(TaskCategory.GENERAL)

  @TypeConverter
  fun fromPriority(value: TaskPriority): String = value.name

  @TypeConverter
  fun toPriority(value: String): TaskPriority =
    runCatching { TaskPriority.valueOf(value) }.getOrDefault(TaskPriority.MEDIUM)
}

@Database(
  entities = [TaskEntity::class, StudyBlockEntity::class, StudySessionEntity::class],
  version = 1,
  exportSchema = false,
)
@TypeConverters(StudentTypeConverters::class)
abstract class StudentDatabase : RoomDatabase() {
  abstract fun taskDao(): TaskDao
  abstract fun studyBlockDao(): StudyBlockDao
  abstract fun studySessionDao(): StudySessionDao

  companion object {
    @Volatile private var INSTANCE: StudentDatabase? = null

    fun getInstance(context: Context): StudentDatabase {
      return INSTANCE
        ?: synchronized(this) {
          val instance =
            Room.databaseBuilder(
                context.applicationContext,
                StudentDatabase::class.java,
                "student_tasks_db",
              )
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
          INSTANCE = instance
          instance
        }
    }
  }
}
