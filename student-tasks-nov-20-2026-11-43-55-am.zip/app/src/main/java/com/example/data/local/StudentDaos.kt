package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
  @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDateMillis ASC")
  fun observeAllTasks(): Flow<List<TaskEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTasks(tasks: List<TaskEntity>)

  @Update
  suspend fun updateTask(task: TaskEntity)

  @Delete
  suspend fun deleteTask(task: TaskEntity)

  @Query("DELETE FROM tasks WHERE id = :taskId")
  suspend fun deleteTaskById(taskId: Long)

  @Query("DELETE FROM tasks WHERE isCompleted = 1")
  suspend fun deleteCompletedTasks()

  @Query("DELETE FROM tasks")
  suspend fun clearAllTasks()

  @Query("SELECT COUNT(*) FROM tasks")
  suspend fun countTasks(): Int
}

@Dao
interface StudyBlockDao {
  @Query("SELECT * FROM study_blocks ORDER BY dayOfWeek ASC, startMinutesFromMidnight ASC")
  fun observeAllBlocks(): Flow<List<StudyBlockEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBlock(block: StudyBlockEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBlocks(blocks: List<StudyBlockEntity>)

  @Update
  suspend fun updateBlock(block: StudyBlockEntity)

  @Query("DELETE FROM study_blocks WHERE id = :blockId")
  suspend fun deleteBlockById(blockId: Long)

  @Query("DELETE FROM study_blocks")
  suspend fun clearAllBlocks()

  @Query("SELECT COUNT(*) FROM study_blocks")
  suspend fun countBlocks(): Int
}

@Dao
interface StudySessionDao {
  @Query("SELECT * FROM study_sessions ORDER BY epochDayMillis DESC LIMIT 14")
  fun observeRecentSessions(): Flow<List<StudySessionEntity>>

  @Query("SELECT * FROM study_sessions WHERE dayKey = :dayKey LIMIT 1")
  suspend fun getSessionForDay(dayKey: String): StudySessionEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSession(session: StudySessionEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSessions(sessions: List<StudySessionEntity>)

  @Query("DELETE FROM study_sessions")
  suspend fun clearAllSessions()
}
