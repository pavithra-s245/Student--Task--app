package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.StudentProfile
import com.example.data.local.StudyBlockEntity
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.ui.theme.OrchidTertiary
import com.example.ui.theme.PastelPinkAccent
import com.example.ui.theme.PastelPinkBlush
import com.example.ui.theme.RoyalPurple
import com.example.util.DateTimeUtils
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskEditorSheet(
  existingTask: TaskEntity?,
  onDismiss: () -> Unit,
  onSave: (
    title: String,
    course: String,
    category: TaskCategory,
    priority: TaskPriority,
    dueDateMillis: Long,
    estimatedMinutes: Int,
    notes: String,
  ) -> Unit,
  onDelete: ((TaskEntity) -> Unit)? = null,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var title by remember(existingTask) { mutableStateOf(existingTask?.title ?: "") }
  var course by remember(existingTask) { mutableStateOf(existingTask?.course ?: "CS 301") }
  var category by remember(existingTask) {
    mutableStateOf(existingTask?.category ?: TaskCategory.ASSIGNMENT)
  }
  var priority by remember(existingTask) {
    mutableStateOf(existingTask?.priority ?: TaskPriority.MEDIUM)
  }
  var dueMillis by remember(existingTask) {
    mutableLongStateOf(
      existingTask?.dueDateMillis
        ?: Calendar.getInstance()
          .apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
          }
          .timeInMillis
    )
  }
  var estimatedMinutes by remember(existingTask) {
    mutableIntStateOf(existingTask?.estimatedMinutes ?: 45)
  }
  var notes by remember(existingTask) { mutableStateOf(existingTask?.notes ?: "") }
  var titleError by remember { mutableStateOf(false) }

  var showDatePicker by remember { mutableStateOf(false) }
  var showTimePicker by remember { mutableStateOf(false) }

  val quickCourses = listOf("CS 301", "MATH 240", "PSYC 215", "DES 310", "BIO 105")
  val durations = listOf(25, 45, 60, 90, 120)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .navigationBarsPadding()
          .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = if (existingTask == null) "New Student Task" else "Edit Task",
          style = MaterialTheme.typography.headlineSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        if (existingTask != null && onDelete != null) {
          TextButton(
            onClick = {
              onDelete(existingTask)
              onDismiss()
            },
            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
          ) {
            Icon(
              imageVector = Icons.Outlined.DeleteOutline,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Delete")
          }
        }
      }

      OutlinedTextField(
        value = title,
        onValueChange = {
          title = it
          if (it.isNotBlank()) titleError = false
        },
        label = { Text("Task or Assignment Title") },
        placeholder = { Text("e.g., Algorithms Problem Set #5") },
        isError = titleError,
        supportingText = if (titleError) ({ Text("Please enter a task title") }) else null,
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("task_title_input"),
      )

      OutlinedTextField(
        value = course,
        onValueChange = { course = it },
        label = { Text("Course / Subject") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("task_course_input"),
      )

      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        quickCourses.forEach { preset ->
          FilterChip(
            selected = course.equals(preset, ignoreCase = true),
            onClick = { course = preset },
            label = { Text(preset) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }

      Text("Category", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TaskCategory.entries.forEach { cat ->
          FilterChip(
            selected = category == cat,
            onClick = { category = cat },
            label = { Text(cat.label) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
              ),
          )
        }
      }

      Text("Priority", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        TaskPriority.entries.forEach { pri ->
          val selected = priority == pri
          FilterChip(
            selected = selected,
            onClick = { priority = pri },
            label = { Text(pri.label) },
            modifier = Modifier.weight(1f),
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
              ),
          )
        }
      }

      Text("Deadline", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val quickDays = listOf("Today" to 0, "Tomorrow" to 1, "+3 Days" to 3, "+1 Week" to 7)
        quickDays.forEach { (label, offset) ->
          OutlinedButton(
            onClick = {
              val oldCal = Calendar.getInstance().apply { timeInMillis = dueMillis }
              val newCal =
                Calendar.getInstance().apply {
                  add(Calendar.DAY_OF_YEAR, offset)
                  set(Calendar.HOUR_OF_DAY, oldCal.get(Calendar.HOUR_OF_DAY))
                  set(Calendar.MINUTE, oldCal.get(Calendar.MINUTE))
                  set(Calendar.SECOND, 0)
                }
              dueMillis = newCal.timeInMillis
            },
            shape = RoundedCornerShape(12.dp),
          ) {
            Text(label, style = MaterialTheme.typography.labelMedium)
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = { showDatePicker = true },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(14.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.CalendarToday,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(DateTimeUtils.formatShortDate(dueMillis))
        }
        OutlinedButton(
          onClick = { showTimePicker = true },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(14.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.Schedule,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          val cal = Calendar.getInstance().apply { timeInMillis = dueMillis }
          val mins = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
          Text(DateTimeUtils.formatMinutesFromMidnight(mins))
        }
      }

      Text("Estimated Study Time", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        durations.forEach { mins ->
          FilterChip(
            selected = estimatedMinutes == mins,
            onClick = { estimatedMinutes = mins },
            label = { Text("${mins}m") },
          )
        }
      }

      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("Notes (optional)") },
        placeholder = { Text("Readings, submission link, grading rubric...") },
        minLines = 2,
        maxLines = 4,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )

      Button(
        onClick = {
          if (title.isBlank()) {
            titleError = true
          } else {
            onSave(title, course, category, priority, dueMillis, estimatedMinutes, notes)
            onDismiss()
          }
        },
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_task_button"),
        shape = RoundedCornerShape(16.dp),
      ) {
        Text(
          text = if (existingTask == null) "Add to Tasks" else "Save Changes",
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }

  if (showDatePicker) {
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = dueMillis)
    DatePickerDialog(
      onDismissRequest = { showDatePicker = false },
      confirmButton = {
        TextButton(
          onClick = {
            datePickerState.selectedDateMillis?.let { utcMillis ->
              val utcCal =
                Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMillis }
              val localCal =
                Calendar.getInstance().apply {
                  timeInMillis = dueMillis
                  set(Calendar.YEAR, utcCal.get(Calendar.YEAR))
                  set(Calendar.MONTH, utcCal.get(Calendar.MONTH))
                  set(Calendar.DAY_OF_MONTH, utcCal.get(Calendar.DAY_OF_MONTH))
                }
              dueMillis = localCal.timeInMillis
            }
            showDatePicker = false
          }
        ) {
          Text("Apply")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
      },
    ) {
      DatePicker(state = datePickerState)
    }
  }

  if (showTimePicker) {
    val cal = Calendar.getInstance().apply { timeInMillis = dueMillis }
    val timeState =
      rememberTimePickerState(
        initialHour = cal.get(Calendar.HOUR_OF_DAY),
        initialMinute = cal.get(Calendar.MINUTE),
        is24Hour = false,
      )
    AlertDialog(
      onDismissRequest = { showTimePicker = false },
      title = { Text("Select Due Time") },
      text = { TimePicker(state = timeState) },
      confirmButton = {
        TextButton(
          onClick = {
            val updated =
              Calendar.getInstance().apply {
                timeInMillis = dueMillis
                set(Calendar.HOUR_OF_DAY, timeState.hour)
                set(Calendar.MINUTE, timeState.minute)
                set(Calendar.SECOND, 0)
              }
            dueMillis = updated.timeInMillis
            showTimePicker = false
          }
        ) {
          Text("Apply")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
      },
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyBlockEditorSheet(
  existingBlock: StudyBlockEntity?,
  initialDayOfWeek: Int,
  onDismiss: () -> Unit,
  onSave: (
    title: String,
    course: String,
    dayOfWeek: Int,
    startMinutes: Int,
    endMinutes: Int,
    location: String,
    colorTag: Int,
  ) -> Unit,
  onDelete: ((Long) -> Unit)? = null,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var title by remember(existingBlock) { mutableStateOf(existingBlock?.title ?: "") }
  var course by remember(existingBlock) { mutableStateOf(existingBlock?.course ?: "CS 301") }
  var dayOfWeek by remember(existingBlock) {
    mutableIntStateOf(existingBlock?.dayOfWeek ?: initialDayOfWeek)
  }
  var startMinutes by remember(existingBlock) {
    mutableIntStateOf(existingBlock?.startMinutesFromMidnight ?: 9 * 60)
  }
  var endMinutes by remember(existingBlock) {
    mutableIntStateOf(existingBlock?.endMinutesFromMidnight ?: 10 * 60 + 30)
  }
  var location by remember(existingBlock) {
    mutableStateOf(existingBlock?.location ?: "Science Library")
  }
  var colorTag by remember(existingBlock) { mutableIntStateOf(existingBlock?.colorTag ?: 0) }
  var titleError by remember { mutableStateOf(false) }

  var pickingStartTime by remember { mutableStateOf(false) }
  var pickingEndTime by remember { mutableStateOf(false) }

  val accentColors =
    listOf(
      RoyalPurple to "Purple",
      PastelPinkAccent to "Pastel Pink",
      OrchidTertiary to "Orchid",
      PastelPinkBlush to "Blush",
    )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .navigationBarsPadding()
          .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = if (existingBlock == null) "New Study Session" else "Edit Study Session",
          style = MaterialTheme.typography.headlineSmall,
        )
        if (existingBlock != null && onDelete != null) {
          TextButton(
            onClick = {
              onDelete(existingBlock.id)
              onDismiss()
            },
            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
          ) {
            Icon(Icons.Outlined.DeleteOutline, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Delete")
          }
        }
      }

      OutlinedTextField(
        value = title,
        onValueChange = {
          title = it
          if (it.isNotBlank()) titleError = false
        },
        label = { Text("Study Focus / Session Title") },
        placeholder = { Text("e.g., Linear Algebra Problem Drill") },
        isError = titleError,
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("schedule_title_input"),
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = course,
          onValueChange = { course = it },
          label = { Text("Course") },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
          value = location,
          onValueChange = { location = it },
          label = { Text("Location") },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1.2f),
        )
      }

      Text("Day of Week", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        (1..7).forEach { day ->
          FilterChip(
            selected = dayOfWeek == day,
            onClick = { dayOfWeek = day },
            label = { Text(DateTimeUtils.dayShortLabel(day)) },
          )
        }
      }

      Text("Time Window", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = { pickingStartTime = true },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text("Start: ${DateTimeUtils.formatMinutesFromMidnight(startMinutes)}")
        }
        OutlinedButton(
          onClick = { pickingEndTime = true },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text("End: ${DateTimeUtils.formatMinutesFromMidnight(endMinutes)}")
        }
      }

      Text("Color Tag", style = MaterialTheme.typography.titleSmall)
      Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        accentColors.forEachIndexed { idx, (color, label) ->
          val selected = colorTag == idx
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (selected) color.copy(alpha = 0.16f) else Color.Transparent,
            border =
              BorderStroke(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) color else MaterialTheme.colorScheme.outlineVariant,
              ),
            modifier = Modifier.clickable { colorTag = idx },
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
              Text(label, style = MaterialTheme.typography.labelSmall)
            }
          }
        }
      }

      Button(
        onClick = {
          if (title.isBlank()) {
            titleError = true
          } else {
            val safeEnd = endMinutes.coerceAtLeast(startMinutes + 30)
            onSave(title, course, dayOfWeek, startMinutes, safeEnd, location, colorTag)
            onDismiss()
          }
        },
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_schedule_button"),
        shape = RoundedCornerShape(16.dp),
      ) {
        Text(
          text = if (existingBlock == null) "Add to Timetable" else "Save Session",
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }

  if (pickingStartTime) {
    val state =
      rememberTimePickerState(
        initialHour = startMinutes / 60,
        initialMinute = startMinutes % 60,
        is24Hour = false,
      )
    AlertDialog(
      onDismissRequest = { pickingStartTime = false },
      title = { Text("Start Time") },
      text = { TimePicker(state = state) },
      confirmButton = {
        TextButton(
          onClick = {
            startMinutes = state.hour * 60 + state.minute
            if (endMinutes <= startMinutes) {
              endMinutes = (startMinutes + 60).coerceAtMost(23 * 60 + 55)
            }
            pickingStartTime = false
          }
        ) {
          Text("Set")
        }
      },
      dismissButton = { TextButton(onClick = { pickingStartTime = false }) { Text("Cancel") } },
    )
  }

  if (pickingEndTime) {
    val state =
      rememberTimePickerState(
        initialHour = endMinutes / 60,
        initialMinute = endMinutes % 60,
        is24Hour = false,
      )
    AlertDialog(
      onDismissRequest = { pickingEndTime = false },
      title = { Text("End Time") },
      text = { TimePicker(state = state) },
      confirmButton = {
        TextButton(
          onClick = {
            endMinutes = (state.hour * 60 + state.minute).coerceAtLeast(startMinutes + 15)
            pickingEndTime = false
          }
        ) {
          Text("Set")
        }
      },
      dismissButton = { TextButton(onClick = { pickingEndTime = false }) { Text("Cancel") } },
    )
  }
}

@Composable
fun EditProfileDialog(
  profile: StudentProfile,
  onDismiss: () -> Unit,
  onSave: (name: String, email: String, major: String, year: String, goalMinutes: Int) -> Unit,
) {
  var name by remember(profile) { mutableStateOf(profile.name) }
  var email by remember(profile) { mutableStateOf(profile.email) }
  var major by remember(profile) { mutableStateOf(profile.major) }
  var year by remember(profile) { mutableStateOf(profile.academicYear) }
  var goalMinutes by remember(profile) { mutableIntStateOf(profile.dailyGoalMinutes) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Edit Student Profile", style = MaterialTheme.typography.titleLarge) },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Full Name") },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
        )
        OutlinedTextField(
          value = email,
          onValueChange = { email = it },
          label = { Text("College Email") },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
        )
        OutlinedTextField(
          value = major,
          onValueChange = { major = it },
          label = { Text("Major") },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
        )
        OutlinedTextField(
          value = year,
          onValueChange = { year = it },
          label = { Text("Academic Year") },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
        )
        Text(
          text = "Daily Study Goal: ${DateTimeUtils.formatMinutesDuration(goalMinutes)}",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.SemiBold,
        )
        Slider(
          value = goalMinutes.toFloat(),
          onValueChange = { goalMinutes = (it.toInt() / 15) * 15 },
          valueRange = 60f..360f,
          colors =
            SliderDefaults.colors(
              thumbColor = MaterialTheme.colorScheme.secondary,
              activeTrackColor = MaterialTheme.colorScheme.primary,
            ),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            name.ifBlank { "Student" },
            email.ifBlank { "student@university.edu" },
            major.ifBlank { "Undeclared" },
            year.ifBlank { "Undergraduate" },
            goalMinutes,
          )
          onDismiss()
        }
      ) {
        Text("Save")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}
