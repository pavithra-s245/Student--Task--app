package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.StudyBlockEntity
import com.example.data.local.TaskEntity
import com.example.ui.components.StudyProgressRing
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.OrchidTertiary
import com.example.ui.theme.PastelPinkAccent
import com.example.ui.theme.PastelPinkBlush
import com.example.ui.theme.RoyalPurple
import com.example.ui.viewmodel.StudentUiState
import com.example.util.DateTimeUtils

@Composable
fun HomeDashboardScreen(
  state: StudentUiState,
  onToggleTask: (TaskEntity) -> Unit,
  onEditTask: (TaskEntity) -> Unit,
  onDeleteTask: (TaskEntity) -> Unit,
  onToggleStudyBlock: (StudyBlockEntity) -> Unit,
  onLogQuickStudy: (Int) -> Unit,
  onNavigateToTasks: () -> Unit,
  onNavigateToSchedule: () -> Unit,
  onNavigateToProfile: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val completionRatio =
    if (state.totalTaskCount == 0) 0f
    else state.completedTaskCount.toFloat() / state.totalTaskCount.toFloat()
  val goalRatio =
    (state.todayStudyMinutes.toFloat() / state.profile.dailyGoalMinutes.coerceAtLeast(1).toFloat())
      .coerceIn(0f, 1f)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 680.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      // Top Personalized Student Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = DateTimeUtils.greetingForTimeOfDay(),
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.secondary,
            )
            Text(
              text = state.profile.name.ifBlank { "Student" },
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onBackground,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primaryContainer,
              ) {
                Text(
                  text = state.profile.major.ifBlank { "College Student" },
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
              }
              Text(
                text = state.profile.academicYear,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          Image(
            painter = painterResource(id = R.drawable.img_student_avatar),
            contentDescription = "Student profile avatar",
            modifier =
              Modifier.size(56.dp)
                .clip(CircleShape)
                .clickable(onClick = onNavigateToProfile)
                .testTag("dashboard_avatar"),
            contentScale = ContentScale.Crop,
          )
        }
      }

      // Study Progress Dashboard Card
      item {
        Card(
          shape = RoundedCornerShape(26.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        ) {
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .background(
                  Brush.linearGradient(
                    listOf(
                      MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                      MaterialTheme.colorScheme.surface,
                      MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                    )
                  )
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "Study Progress",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.secondaryContainer,
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Icon(
                    imageVector = Icons.Outlined.LocalFireDepartment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(14.dp),
                  )
                  Text(
                    text = "${DateTimeUtils.formatMinutesDuration(state.weeklyStudyMinutes)} wk",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                  )
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
              StudyProgressRing(
                progress = completionRatio,
                centerValue = "${(completionRatio * 100).toInt()}%",
                centerLabel = "Tasks",
              )

              Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  DashboardMiniStat(
                    label = "Completed",
                    value = "${state.completedTaskCount}/${state.totalTaskCount}",
                  )
                  DashboardMiniStat(
                    label = "Due Soon",
                    value = "${state.dueTodayCount}",
                    highlight = state.dueTodayCount > 0,
                  )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text(
                      text = "Today's Focus",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                      text =
                        "${DateTimeUtils.formatMinutesDuration(state.todayStudyMinutes)} / ${DateTimeUtils.formatMinutesDuration(state.profile.dailyGoalMinutes)}",
                      style =
                        MaterialTheme.typography.labelSmall.copy(
                          fontFamily = JetBrainsMonoFontFamily
                        ),
                      fontWeight = FontWeight.SemiBold,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                  LinearProgressIndicator(
                    progress = { goalRatio },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.primaryContainer,
                  )
                }
              }
            }

            // Quick Study Session Logger
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "Quick log:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              listOf(15, 30, 45).forEach { mins ->
                AssistChip(
                  onClick = { onLogQuickStudy(mins) },
                  label = { Text("+${mins}m") },
                  leadingIcon = {
                    Icon(
                      imageVector = Icons.Filled.Add,
                      contentDescription = null,
                      modifier = Modifier.size(14.dp),
                    )
                  },
                  colors =
                    AssistChipDefaults.assistChipColors(
                      containerColor = MaterialTheme.colorScheme.surface,
                      labelColor = MaterialTheme.colorScheme.primary,
                      leadingIconContentColor = MaterialTheme.colorScheme.secondary,
                    ),
                  modifier = Modifier.testTag("quick_log_${mins}m"),
                )
              }
            }
          }
        }
      }

      // Urgent Assignment Deadlines Section
      item {
        SectionHeaderRow(
          title = "Assignment Deadlines",
          icon = Icons.Outlined.NotificationsActive,
          actionLabel = "All Tasks",
          onAction = onNavigateToTasks,
        )
      }

      if (state.urgentDeadlines.isEmpty()) {
        item {
          EmptyDashboardCard(
            title = "All caught up!",
            subtitle = "No pending assignments right now. Tap + to plan ahead.",
          )
        }
      } else {
        items(state.urgentDeadlines.take(3), key = { "home_task_${it.id}" }) { task ->
          TaskItemCard(
            task = task,
            onToggleComplete = onToggleTask,
            onEdit = onEditTask,
            onDelete = onDeleteTask,
            showActions = false,
          )
        }
      }

      // Today's Study Timetable Preview
      item {
        SectionHeaderRow(
          title = "Today's Study Timetable",
          icon = Icons.Outlined.CalendarToday,
          actionLabel = "Full Schedule",
          onAction = onNavigateToSchedule,
        )
      }

      if (state.todayBlocks.isEmpty()) {
        item {
          EmptyDashboardCard(
            title = "No study blocks for ${DateTimeUtils.dayFullLabel(DateTimeUtils.currentDayOfWeekMon1Sun7())}",
            subtitle = "Head to Schedule to add focused study sessions for today.",
          )
        }
      } else {
        items(state.todayBlocks, key = { "home_block_${it.id}" }) { block ->
          CompactStudyBlockCard(block = block, onToggle = onToggleStudyBlock)
        }
      }

      item { Spacer(modifier = Modifier.height(72.dp)) }
    }
  }
}

@Composable
private fun DashboardMiniStat(label: String, value: String, highlight: Boolean = false) {
  Column {
    Text(
      text = value,
      style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
      fontWeight = FontWeight.Bold,
      color = if (highlight) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun SectionHeaderRow(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  actionLabel: String,
  onAction: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
      )
    }
    TextButton(onClick = onAction) {
      Text(actionLabel)
      Spacer(modifier = Modifier.width(4.dp))
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        modifier = Modifier.size(16.dp),
      )
    }
  }
}

@Composable
private fun CompactStudyBlockCard(
  block: StudyBlockEntity,
  onToggle: (StudyBlockEntity) -> Unit,
) {
  val accentColor =
    when (block.colorTag) {
      1 -> PastelPinkAccent
      2 -> OrchidTertiary
      3 -> PastelPinkBlush
      else -> RoyalPurple
    }

  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier = Modifier.width(5.dp).height(48.dp).clip(RoundedCornerShape(50)).background(accentColor)
      )

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = block.course,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = accentColor,
          )
          Text(
            text =
              "${DateTimeUtils.formatMinutesFromMidnight(block.startMinutesFromMidnight)} - ${DateTimeUtils.formatMinutesFromMidnight(block.endMinutesFromMidnight)}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Text(
          text = block.title,
          style = MaterialTheme.typography.titleMedium,
          textDecoration = if (block.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
          color =
            if (block.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.onSurface,
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.LocationOn,
            contentDescription = null,
            modifier = Modifier.size(13.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = block.location,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      Box(
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .clip(CircleShape)
            .clickable { onToggle(block) },
        contentAlignment = Alignment.Center,
      ) {
        Surface(
          modifier = Modifier.size(28.dp),
          shape = CircleShape,
          color =
            if (block.isCompleted) MaterialTheme.colorScheme.secondary
            else MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (block.isCompleted) Icons.Filled.Check else Icons.Outlined.Schedule,
              contentDescription = if (block.isCompleted) "Completed" else "Mark session done",
              tint = if (block.isCompleted) Color.White else MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyDashboardCard(title: String, subtitle: String) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(title, style = MaterialTheme.typography.titleMedium)
      Text(
        subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
