package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

@Composable
fun WelcomeLoginScreen(
  initialName: String,
  initialEmail: String,
  initialMajor: String,
  initialYear: String,
  onSignIn: (name: String, email: String, major: String, year: String) -> Unit,
) {
  var name by remember(initialName) { mutableStateOf(initialName) }
  var email by remember(initialEmail) { mutableStateOf(initialEmail) }
  var major by remember(initialMajor) {
    mutableStateOf(initialMajor.ifBlank { "Computer Science" })
  }
  var academicYear by remember(initialYear) {
    mutableStateOf(initialYear.ifBlank { "Junior" })
  }
  var nameError by remember { mutableStateOf(false) }

  val majorPresets = listOf("Computer Science", "Biology", "Psychology", "Design", "Economics")
  val yearPresets = listOf("Freshman", "Sophomore", "Junior", "Senior", "Grad")

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            listOf(
              MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
              MaterialTheme.colorScheme.background,
              MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f),
            )
          )
        )
        .safeDrawingPadding(),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier =
        Modifier.widthIn(max = 560.dp)
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Hero Illustration Banner
      Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      ) {
        Box(modifier = Modifier.fillMaxWidth()) {
          Image(
            painter = painterResource(id = R.drawable.img_welcome_study),
            contentDescription = "College student study desk illustration",
            modifier = Modifier.fillMaxWidth().height(185.dp),
            contentScale = ContentScale.Crop,
          )
          Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.94f),
            modifier = Modifier.padding(14.dp).align(Alignment.TopStart),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(15.dp),
              )
              Text(
                text = "Student Task Manager",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
          }
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = stringResource(R.string.welcome_title),
          style = MaterialTheme.typography.displaySmall,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = stringResource(R.string.welcome_subtitle),
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      // Login / Student Profile Card
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Text(
            text = "Student Sign In",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
          )

          OutlinedTextField(
            value = name,
            onValueChange = {
              name = it
              if (it.isNotBlank()) nameError = false
            },
            label = { Text("Full Name") },
            placeholder = { Text("e.g., Maya Lin") },
            leadingIcon = { Icon(Icons.Outlined.Badge, contentDescription = null) },
            isError = nameError,
            supportingText = if (nameError) ({ Text("Please enter your name to sign in") }) else null,
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("login_name_input"),
          )

          OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("College Email") },
            placeholder = { Text("maya.lin@university.edu") },
            leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("login_email_input"),
          )

          OutlinedTextField(
            value = major,
            onValueChange = { major = it },
            label = { Text("Major / Department") },
            leadingIcon = { Icon(Icons.Outlined.School, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("login_major_input"),
          )

          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            majorPresets.forEach { preset ->
              FilterChip(
                selected = major.equals(preset, ignoreCase = true),
                onClick = { major = preset },
                label = { Text(preset) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                  ),
              )
            }
          }

          Text(
            text = "Academic Year",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            yearPresets.forEach { yr ->
              FilterChip(
                selected = academicYear.startsWith(yr, ignoreCase = true),
                onClick = { academicYear = yr },
                label = { Text(yr) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                  ),
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          Button(
            onClick = {
              if (name.isBlank()) {
                nameError = true
              } else {
                onSignIn(
                  name,
                  email.ifBlank {
                    "${name.trim().lowercase().replace(" ", ".")}@university.edu"
                  },
                  major,
                  academicYear,
                )
              }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp).testTag("login_submit_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          ) {
            Text("Continue to Dashboard", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
          }

          OutlinedButton(
            onClick = {
              onSignIn(
                name.ifBlank { "Maya Lin" },
                email.ifBlank { "maya.lin@university.edu" },
                major.ifBlank { "Computer Science" },
                academicYear.ifBlank { "Junior" },
              )
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("login_demo_button"),
            shape = RoundedCornerShape(16.dp),
          ) {
            Text("Quick Demo Sign In (Maya Lin)")
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
    }
  }
}
