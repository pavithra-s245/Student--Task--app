package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme =
  lightColorScheme(
    primary = RoyalPurple,
    onPrimary = Color.White,
    primaryContainer = SoftLavender,
    onPrimaryContainer = DeepIndigoInk,
    secondary = PastelPinkAccent,
    onSecondary = Color.White,
    secondaryContainer = PastelPinkSoft,
    onSecondaryContainer = DeepRoseInk,
    tertiary = OrchidTertiary,
    onTertiary = Color.White,
    tertiaryContainer = OrchidContainer,
    onTertiaryContainer = DeepIndigoInk,
    background = AlabasterBg,
    onBackground = PlumInk,
    surface = PureWhiteSurface,
    onSurface = PlumInk,
    surfaceVariant = LilacSurfaceContainer,
    onSurfaceVariant = MutedPlumInk,
    surfaceContainerLowest = PureWhiteSurface,
    surfaceContainerLow = LilacSurfaceContainer,
    surfaceContainer = LilacSurfaceContainer,
    surfaceContainerHigh = LilacSurfaceHigh,
    outline = SoftOutline,
    outlineVariant = SoftOutline,
    error = UrgentRose,
    onError = Color.White,
    errorContainer = UrgentRoseContainer,
    onErrorContainer = DeepRoseInk,
  )

private val DarkColorScheme =
  darkColorScheme(
    primary = LavenderLight,
    onPrimary = DeepIndigoInk,
    primaryContainer = DeepPurpleContainer,
    onPrimaryContainer = SoftLavender,
    secondary = PastelPinkDark,
    onSecondary = DeepRoseInk,
    secondaryContainer = PastelPinkContainerDark,
    onSecondaryContainer = PastelPinkSoft,
    tertiary = PastelPinkBlush,
    onTertiary = DeepRoseInk,
    tertiaryContainer = DarkPlumSurfaceHigh,
    onTertiaryContainer = SoftLavender,
    background = DarkPlumBg,
    onBackground = LightInk,
    surface = DarkPlumSurface,
    onSurface = LightInk,
    surfaceVariant = DarkPlumSurfaceHigh,
    onSurfaceVariant = MutedLightInk,
    surfaceContainerLowest = DarkPlumBg,
    surfaceContainerLow = DarkPlumSurface,
    surfaceContainer = DarkPlumSurface,
    surfaceContainerHigh = DarkPlumSurfaceHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutline,
    error = Color(0xFFFF8CB0),
    onError = DeepRoseInk,
    errorContainer = Color(0xFF6B1836),
    onErrorContainer = UrgentRoseContainer,
  )

val StudentTaskShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
  )

@Composable
fun StudentTaskTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    shapes = StudentTaskShapes,
    content = content,
  )
}
