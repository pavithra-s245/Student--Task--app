package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.StudentDatabase
import com.example.data.local.StudentPreferencesRepository
import com.example.data.local.StudentProfile
import com.example.data.local.StudyBlockEntity
import com.example.data.local.StudySessionEntity
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.data.local.ThemePreference
import com.example.data.repository.StudentTaskRepository
import com.example.util.DateTimeUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TaskFilter(val label: String) {
  ALL("All"),
  ASSIGNMENTS("Assignments"),
  ACTIVE("Pending"),
  COMPLETED("Completed"),
}

enum class TaskSort(val label: String) {
  DUE_DATE("Deadline"),
  PRIORITY("Priority"),
}

data class DayStudyPoint(
  val dayShort: String,
  val minutes: Int,
  val isToday: Boolean,
)

data class CourseProgress(
  val course: String,
  val completed: Int,
  val total: Int,
)

data class StudentUiState(
  val isInitialized: Boolean = false,
  val profile: StudentProfile = StudentProfile(),
  val allTasks: List<TaskEntity> = emptyList(),
  val filteredTasks: List<TaskEntity> = emptyList(),
  val urgentDeadlines: List<TaskEntity> = emptyList(),
  val allStudyBlocks: List<StudyBlockEntity> = emptyList(),
  val selectedDayBlocks: List<StudyBlockEntity> = emptyList(),
  val todayBlocks: List<StudyBlockEntity> = emptyList(),
  val selectedTaskFilter: TaskFilter = TaskFilter.ALL,
  val selectedSort: TaskSort = TaskSort.DUE_DATE,
  val searchQuery: String = "",
  val selectedDayOfWeek: Int = DateTimeUtils.currentDayOfWeekMon1Sun7(),
  val completedTaskCount: Int = 0,
  val totalTaskCount: Int = 0,
  val overdueCount: Int = 0,
  val dueTodayCount: Int = 0,
  val todayStudyMinutes: Int = 0,
  val weeklyStudyMinutes: Int = 0,
  val weeklyChartPoints: List<DayStudyPoint> = emptyList(),
  val courseBreakdown: List<CourseProgress> = emptyList(),
)

private data class FilterState(
  val filter: TaskFilter,
  val sort: TaskSort,
  val query: String,
  val selectedDay: Int,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val repository: StudentTaskRepository

  init {
    val db = StudentDatabase.getInstance(application)
    val prefs = StudentPreferencesRepository(application)
    repository =
      StudentTaskRepository(
        taskDao = db.taskDao(),
        studyBlockDao = db.studyBlockDao(),
        studySessionDao = db.studySessionDao(),
        preferencesRepository = prefs,
      )
    viewModelScope.launch { repository.ensureInitialDataSeeded() }
  }

  private val selectedFilter = MutableStateFlow(TaskFilter.ALL)
  private val selectedSort = MutableStateFlow(TaskSort.DUE_DATE)
  private val searchQuery = MutableStateFlow("")
  private val selectedDay = MutableStateFlow(DateTimeUtils.currentDayOfWeekMon1Sun7())

  private val filterStateFlow =
    combine(selectedFilter, selectedSort, searchQuery, selectedDay) { f, s, q, d ->
      FilterState(f, s, q, d)
    }

  val uiState: StateFlow<StudentUiState> =
    combine(
        repository.studentProfile,
        repository.allTasks,
        repository.allStudyBlocks,
        repository.recentStudySessions,
        filterStateFlow,
      ) { profile, tasks, blocks, sessions, filterState ->
        val filtered =
          tasks
            .filter { task ->
              val matchesFilter =
                when (filterState.filter) {
                  TaskFilter.ALL -> true
                  TaskFilter.ASSIGNMENTS ->
                    task.category == TaskCategory.ASSIGNMENT ||
                      task.category == TaskCategory.EXAM ||
                      task.category == TaskCategory.PROJECT
                  TaskFilter.ACTIVE -> !task.isCompleted
                  TaskFilter.COMPLETED -> task.isCompleted
                }
              val q = filterState.query.trim().lowercase(Locale.US)
              val matchesQuery =
                q.isEmpty() ||
                  task.title.lowercase(Locale.US).contains(q) ||
                  task.course.lowercase(Locale.US).contains(q)
              matchesFilter && matchesQuery
            }
            .let { list ->
              when (filterState.sort) {
                TaskSort.DUE_DATE ->
                  list.sortedWith(compareBy<TaskEntity> { it.isCompleted }.thenBy { it.dueDateMillis })
                TaskSort.PRIORITY ->
                  list.sortedWith(
                    compareBy<TaskEntity> { it.isCompleted }
                      .thenByDescending { it.priority.weight }
                      .thenBy { it.dueDateMillis }
                  )
              }
            }

        val urgent =
          tasks
            .filter { !it.isCompleted }
            .sortedBy { it.dueDateMillis }

        val todayDay = DateTimeUtils.currentDayOfWeekMon1Sun7()
        val selectedDayBlocks =
          blocks
            .filter { it.dayOfWeek == filterState.selectedDay }
            .sortedBy { it.startMinutesFromMidnight }
        val todayBlocks =
          blocks
            .filter { it.dayOfWeek == todayDay }
            .sortedBy { it.startMinutesFromMidnight }

        val completedCount = tasks.count { it.isCompleted }
        val overdueCount =
          tasks.count {
            DateTimeUtils.getDeadlineUrgency(it.dueDateMillis, it.isCompleted) ==
              DateTimeUtils.DeadlineUrgency.OVERDUE
          }
        val dueTodayCount =
          tasks.count {
            val u = DateTimeUtils.getDeadlineUrgency(it.dueDateMillis, it.isCompleted)
            u == DateTimeUtils.DeadlineUrgency.DUE_TODAY || u == DateTimeUtils.DeadlineUrgency.OVERDUE
          }

        val chartPoints = buildWeeklyPoints(sessions)
        val todayMinutes = chartPoints.lastOrNull()?.minutes ?: 0
        val weeklyMinutes = chartPoints.sumOf { it.minutes }

        val courseBreakdown =
          tasks
            .groupBy { it.course.ifBlank { "General" } }
            .map { (course, courseTasks) ->
              CourseProgress(
                course = course,
                completed = courseTasks.count { it.isCompleted },
                total = courseTasks.size,
              )
            }
            .sortedByDescending { it.total }

        StudentUiState(
          isInitialized = true,
          profile = profile,
          allTasks = tasks,
          filteredTasks = filtered,
          urgentDeadlines = urgent,
          allStudyBlocks = blocks,
          selectedDayBlocks = selectedDayBlocks,
          todayBlocks = todayBlocks,
          selectedTaskFilter = filterState.filter,
          selectedSort = filterState.sort,
          searchQuery = filterState.query,
          selectedDayOfWeek = filterState.selectedDay,
          completedTaskCount = completedCount,
          totalTaskCount = tasks.size,
          overdueCount = overdueCount,
          dueTodayCount = dueTodayCount,
          todayStudyMinutes = todayMinutes,
          weeklyStudyMinutes = weeklyMinutes,
          weeklyChartPoints = chartPoints,
          courseBreakdown = courseBreakdown,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StudentUiState(),
      )

  private fun buildWeeklyPoints(sessions: List<StudySessionEntity>): List<DayStudyPoint> {
    val sessionMap = sessions.associateBy { it.dayKey }
    val dayFmt = SimpleDateFormat("EEEEE", Locale.US)
    return (6 downTo 0).map { daysAgo ->
      val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
      val key = StudentTaskRepository.formatDayKey(cal)
      val minutes = sessionMap[key]?.minutesStudied ?: 0
      DayStudyPoint(
        dayShort = dayFmt.format(cal.time),
        minutes = minutes,
        isToday = daysAgo == 0,
      )
    }
  }

  fun setTaskFilter(filter: TaskFilter) {
    selectedFilter.value = filter
  }

  fun setTaskSort(sort: TaskSort) {
    selectedSort.value = sort
  }

  fun setSearchQuery(query: String) {
    searchQuery.value = query
  }

  fun selectDayOfWeek(day: Int) {
    selectedDay.value = day.coerceIn(1, 7)
  }

  fun signIn(name: String, email: String, major: String, academicYear: String) {
    viewModelScope.launch { repository.signInStudent(name, email, major, academicYear) }
  }

  fun signOut() {
    viewModelScope.launch { repository.signOut() }
  }

  fun updateProfile(
    name: String,
    email: String,
    major: String,
    academicYear: String,
    dailyGoalMinutes: Int,
  ) {
    viewModelScope.launch {
      repository.updateProfile(name, email, major, academicYear, dailyGoalMinutes)
    }
  }

  fun setThemePreference(theme: ThemePreference) {
    viewModelScope.launch { repository.setThemePreference(theme) }
  }

  fun setDailyGoalMinutes(minutes: Int) {
    viewModelScope.launch { repository.setDailyGoalMinutes(minutes) }
  }

  fun saveTask(
    existingId: Long = 0L,
    title: String,
    course: String,
    category: TaskCategory,
    priority: TaskPriority,
    dueDateMillis: Long,
    estimatedMinutes: Int,
    notes: String,
    isCompleted: Boolean = false,
  ) {
    viewModelScope.launch {
      repository.saveTask(
        TaskEntity(
          id = existingId,
          title = title.trim(),
          course = course.trim().ifEmpty { "General" },
          category = category,
          priority = priority,
          dueDateMillis = dueDateMillis,
          estimatedMinutes = estimatedMinutes,
          notes = notes.trim(),
          isCompleted = isCompleted,
          completedAtMillis = if (isCompleted) System.currentTimeMillis() else null,
        )
      )
    }
  }

  fun toggleTaskComplete(task: TaskEntity) {
    viewModelScope.launch { repository.toggleTaskCompletion(task) }
  }

  fun deleteTask(task: TaskEntity) {
    viewModelScope.launch { repository.deleteTask(task) }
  }

  fun restoreTask(task: TaskEntity) {
    viewModelScope.launch { repository.saveTask(task) }
  }

  fun clearCompletedTasks() {
    viewModelScope.launch { repository.clearCompletedTasks() }
  }

  fun saveStudyBlock(
    existingId: Long = 0L,
    title: String,
    course: String,
    dayOfWeek: Int,
    startMinutesFromMidnight: Int,
    endMinutesFromMidnight: Int,
    location: String,
    colorTag: Int,
    isCompleted: Boolean = false,
  ) {
    viewModelScope.launch {
      repository.saveStudyBlock(
        StudyBlockEntity(
          id = existingId,
          title = title.trim(),
          course = course.trim().ifEmpty { "Study" },
          dayOfWeek = dayOfWeek,
          startMinutesFromMidnight = startMinutesFromMidnight,
          endMinutesFromMidnight = endMinutesFromMidnight.coerceAtLeast(startMinutesFromMidnight + 15),
          location = location.trim().ifEmpty { "Campus Library" },
          colorTag = colorTag,
          isCompleted = isCompleted,
        )
      )
    }
  }

  fun toggleStudyBlockComplete(block: StudyBlockEntity) {
    viewModelScope.launch { repository.toggleStudyBlockCompletion(block) }
  }

  fun deleteStudyBlock(blockId: Long) {
    viewModelScope.launch { repository.deleteStudyBlock(blockId) }
  }

  fun logQuickStudyMinutes(minutes: Int) {
    viewModelScope.launch { repository.logStudyMinutes(minutes) }
  }

  fun resetSampleData() {
    viewModelScope.launch { repository.resetStarterSampleData() }
  }
}
