package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.StudyBlockEntity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.OrchidTertiary
import com.example.ui.theme.PastelPinkAccent
import com.example.ui.theme.PastelPinkBlush
import com.example.ui.theme.RoyalPurple
import com.example.ui.viewmodel.StudentUiState
import com.example.util.DateTimeUtils

@Composable
fun ScheduleScreen(
  state: StudentUiState,
  onSelectDay: (Int) -> Unit,
  onAddBlock: () -> Unit,
  onEditBlock: (StudyBlockEntity) -> Unit,
  onToggleBlock: (StudyBlockEntity) -> Unit,
  onDeleteBlock: (Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  val today = DateTimeUtils.currentDayOfWeekMon1Sun7()
  val totalPlannedMinutes =
    state.selectedDayBlocks.sumOf { (it.endMinutesFromMidnight - it.startMinutesFromMidnight).coerceAtLeast(0) }
  val completedBlocks = state.selectedDayBlocks.count { it.isCompleted }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 680.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "Study Timetable",
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = "${DateTimeUtils.dayFullLabel(state.selectedDayOfWeek)} · ${DateTimeUtils.formatMinutesDuration(totalPlannedMinutes)} planned",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          FilledTonalButton(
            onClick = onAddBlock,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.testTag("add_schedule_block_button"),
          ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Session")
          }
        }
      }

      // Day of Week Selector Strip
      item {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          (1..7).forEach { day ->
            val selected = state.selectedDayOfWeek == day
            val hasBlocks = state.allStudyBlocks.any { it.dayOfWeek == day }
            val isToday = day == today

            Surface(
              shape = RoundedCornerShape(18.dp),
              color =
                when {
                  selected -> MaterialTheme.colorScheme.primary
                  isToday -> MaterialTheme.colorScheme.secondaryContainer
                  else -> MaterialTheme.colorScheme.surface
                },
              border =
                if (!selected)
                  BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))
                else null,
              modifier =
                Modifier.clip(RoundedCornerShape(18.dp))
                  .clickable { onSelectDay(day) }
                  .testTag("day_tab_$day"),
            ) {
              Column(
                modifier = Modifier.padding(horizontal = 15.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Text(
                  text = DateTimeUtils.dayShortLabel(day),
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.SemiBold,
                  color =
                    when {
                      selected -> MaterialTheme.colorScheme.onPrimary
                      isToday -> MaterialTheme.colorScheme.onSecondaryContainer
                      else -> MaterialTheme.colorScheme.onSurface
                    },
                )
                Box(
                  modifier =
                    Modifier.size(6.dp)
                      .clip(CircleShape)
                      .background(
                        when {
                          !hasBlocks -> Color.Transparent
                          selected -> MaterialTheme.colorScheme.secondaryContainer
                          else -> MaterialTheme.colorScheme.secondary
                        }
                      )
                )
              }
            }
          }
        }
      }

      // Day Progress Strip
      if (state.selectedDayBlocks.isNotEmpty()) {
        item {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.CalendarToday,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(16.dp),
                )
                Text(
                  text = "${state.selectedDayBlocks.size} study sessions",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
              }
              Text(
                text = "$completedBlocks/${state.selectedDayBlocks.size} completed",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.secondary,
              )
            }
          }
        }
      }

      if (state.selectedDayBlocks.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(22.dp),
            colors =
              CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.Schedule,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp),
              )
              Text(
                text = "Open Day on ${DateTimeUtils.dayFullLabel(state.selectedDayOfWeek)}",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = "Schedule a focused study block to build your daily college routine.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      } else {
        items(state.selectedDayBlocks, key = { it.id }) { block ->
          TimelineBlockCard(
            block = block,
            onToggle = onToggleBlock,
            onEdit = onEditBlock,
            onDelete = { onDeleteBlock(block.id) },
          )
        }
      }

      item { Spacer(modifier = Modifier.height(76.dp)) }
    }
  }
}

@Composable
private fun TimelineBlockCard(
  block: StudyBlockEntity,
  onToggle: (StudyBlockEntity) -> Unit,
  onEdit: (StudyBlockEntity) -> Unit,
  onDelete: () -> Unit,
) {
  val accentColor =
    when (block.colorTag) {
      1 -> PastelPinkAccent
      2 -> OrchidTertiary
      3 -> PastelPinkBlush
      else -> RoyalPurple
    }
  val duration = (block.endMinutesFromMidnight - block.startMinutesFromMidnight).coerceAtLeast(0)

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalAlignment = Alignment.Top,
  ) {
    // Left Time Gutter
    Column(
      modifier = Modifier.width(68.dp).padding(top = 8.dp),
      horizontalAlignment = Alignment.End,
    ) {
      Text(
        text = DateTimeUtils.formatMinutesFromMidnight(block.startMinutesFromMidnight),
        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onBackground,
      )
      Text(
        text = DateTimeUtils.formatMinutesDuration(duration),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    // Card
    Card(
      modifier = Modifier.weight(1f).testTag("schedule_card_${block.id}"),
      shape = RoundedCornerShape(20.dp),
      colors =
        CardDefaults.cardColors(
          containerColor =
            if (block.isCompleted) MaterialTheme.colorScheme.surfaceContainerLow
            else MaterialTheme.colorScheme.surface
        ),
      border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
      onClick = { onEdit(block) },
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(14.dp),
        verticalAlignment = Alignment.Top,
      ) {
        Box(
          modifier =
            Modifier.width(5.dp).height(64.dp).clip(RoundedCornerShape(50)).background(accentColor)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Surface(shape = RoundedCornerShape(8.dp), color = accentColor.copy(alpha = 0.14f)) {
              Text(
                text = block.course,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
              )
            }

            Box(
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .clip(CircleShape)
                  .clickable { onToggle(block) }
                  .testTag("toggle_block_${block.id}"),
              contentAlignment = Alignment.Center,
            ) {
              Surface(
                modifier = Modifier.size(26.dp),
                shape = CircleShape,
                color = if (block.isCompleted) accentColor else Color.Transparent,
                border = BorderStroke(2.dp, accentColor),
              ) {
                if (block.isCompleted) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Filled.Check,
                      contentDescription = "Session completed",
                      tint = Color.White,
                      modifier = Modifier.size(15.dp),
                    )
                  }
                }
              }
            }
          }

          Text(
            text = block.title,
            style = MaterialTheme.typography.titleMedium,
            textDecoration = if (block.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
            color =
              if (block.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant
              else MaterialTheme.colorScheme.onSurface,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.LocationOn,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Text(
                text = block.location,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }

            Row {
              IconButton(onClick = { onEdit(block) }, modifier = Modifier.size(32.dp)) {
                Icon(
                  Icons.Outlined.Edit,
                  contentDescription = "Edit session",
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
              IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(
                  Icons.Outlined.DeleteOutline,
                  contentDescription = "Delete session",
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.error,
                )
              }
            }
          }
        }
      }
    }
  }
}
