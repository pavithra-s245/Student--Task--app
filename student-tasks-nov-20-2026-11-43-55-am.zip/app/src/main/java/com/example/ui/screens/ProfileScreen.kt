package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.BrightnessAuto
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ThemePreference
import com.example.ui.components.EditProfileDialog
import com.example.ui.components.WeeklyStudyBarChart
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.StudentUiState
import com.example.util.DateTimeUtils

@Composable
fun ProfileScreen(
  state: StudentUiState,
  onUpdateProfile: (name: String, email: String, major: String, year: String, goalMinutes: Int) -> Unit,
  onThemeChange: (ThemePreference) -> Unit,
  onClearCompleted: () -> Unit,
  onResetSampleData: () -> Unit,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showEditDialog by remember { mutableStateOf(false) }

  val completionRate =
    if (state.totalTaskCount == 0) 0
    else ((state.completedTaskCount * 100f) / state.totalTaskCount).toInt()

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 680.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Text(
          text = "Student Profile",
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      // Profile Identity Card
      item {
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_student_avatar),
              contentDescription = "Student avatar",
              modifier = Modifier.size(68.dp).clip(CircleShape),
              contentScale = ContentScale.Crop,
            )

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text(
                text = state.profile.name.ifBlank { "Student" },
                style = MaterialTheme.typography.titleLarge,
              )
              Text(
                text = state.profile.email.ifBlank { "student@university.edu" },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Spacer(modifier = Modifier.height(2.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                  Text(
                    text = state.profile.major,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                  )
                }
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                  Text(
                    text = state.profile.academicYear,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                  )
                }
              }
            }

            IconButton(
              onClick = { showEditDialog = true },
              modifier = Modifier.testTag("edit_profile_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.Edit,
                contentDescription = "Edit profile",
                tint = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }

      // Expanded Study Progress Dashboard
      item {
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.BarChart,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                )
                Text(
                  text = "Study Progress Dashboard",
                  style = MaterialTheme.typography.titleMedium,
                )
              }
              Text(
                text = "Goal: ${DateTimeUtils.formatMinutesDuration(state.profile.dailyGoalMinutes)}/day",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              ProgressMetricBox(
                value = DateTimeUtils.formatMinutesDuration(state.weeklyStudyMinutes),
                label = "Weekly Study",
                modifier = Modifier.weight(1f),
              )
              ProgressMetricBox(
                value = "$completionRate%",
                label = "Completion",
                modifier = Modifier.weight(1f),
              )
              ProgressMetricBox(
                value = "${state.allStudyBlocks.count { it.isCompleted }}",
                label = "Blocks Done",
                modifier = Modifier.weight(1f),
              )
            }

            WeeklyStudyBarChart(
              points = state.weeklyChartPoints,
              dailyGoalMinutes = state.profile.dailyGoalMinutes,
            )

            if (state.courseBreakdown.isNotEmpty()) {
              Text(
                text = "Course Task Progress",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.courseBreakdown.take(5).forEach { course ->
                  val ratio =
                    if (course.total == 0) 0f else course.completed.toFloat() / course.total.toFloat()
                  Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Text(
                        text = course.course,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                      )
                      Text(
                        text = "${course.completed}/${course.total} done",
                        style =
                          MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily
                          ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                    LinearProgressIndicator(
                      progress = { ratio },
                      modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(50)),
                      color = MaterialTheme.colorScheme.primary,
                      trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Theme & Local Data Controls
      item {
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Text(text = "Appearance & Storage", style = MaterialTheme.typography.titleMedium)

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              ThemePreference.entries.forEach { pref ->
                val icon =
                  when (pref) {
                    ThemePreference.LIGHT -> Icons.Outlined.LightMode
                    ThemePreference.DARK -> Icons.Outlined.DarkMode
                    ThemePreference.SYSTEM -> Icons.Outlined.BrightnessAuto
                  }
                FilterChip(
                  selected = state.profile.themePreference == pref,
                  onClick = { onThemeChange(pref) },
                  label = { Text(pref.label) },
                  leadingIcon = {
                    Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                  },
                  modifier = Modifier.weight(1f),
                  colors =
                    FilterChipDefaults.filterChipColors(
                      selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                      selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    ),
                )
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              TextButton(onClick = onClearCompleted) {
                Icon(
                  Icons.Outlined.CleaningServices,
                  contentDescription = null,
                  modifier = Modifier.size(17.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Clear Completed")
              }
              TextButton(onClick = onResetSampleData) {
                Icon(
                  Icons.Outlined.RestartAlt,
                  contentDescription = null,
                  modifier = Modifier.size(17.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Restore Sample Week")
              }
            }
          }
        }
      }

      // Sign Out
      item {
        OutlinedButton(
          onClick = onSignOut,
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sign_out_button"),
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.Logout,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Sign Out to Welcome Screen")
        }
      }

      item { Spacer(modifier = Modifier.height(76.dp)) }
    }
  }

  if (showEditDialog) {
    EditProfileDialog(
      profile = state.profile,
      onDismiss = { showEditDialog = false },
      onSave = onUpdateProfile,
    )
  }
}

@Composable
private fun ProgressMetricBox(value: String, label: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLow,
  ) {
    Column(
      modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
