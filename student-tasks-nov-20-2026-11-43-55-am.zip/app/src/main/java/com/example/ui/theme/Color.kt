package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Purple & Pastel Pink Palette — Light Mode
val RoyalPurple = Color(0xFF5B3CC4)
val DeepPlum = Color(0xFF3E2399)
val SoftLavender = Color(0xFFEDE7FF)
val DeepIndigoInk = Color(0xFF221359)

val PastelPinkAccent = Color(0xFFC94B84)
val PastelPinkSoft = Color(0xFFFADCE9)
val PastelPinkBlush = Color(0xFFF5B7D2)
val DeepRoseInk = Color(0xFF5A1436)

val OrchidTertiary = Color(0xFF835CD6)
val OrchidContainer = Color(0xFFF3EBFF)

val AlabasterBg = Color(0xFFFCF9FE)
val PureWhiteSurface = Color(0xFFFFFFFF)
val LilacSurfaceContainer = Color(0xFFF5EFFB)
val LilacSurfaceHigh = Color(0xFFECE3F7)
val PlumInk = Color(0xFF1C162E)
val MutedPlumInk = Color(0xFF5F5678)
val SoftOutline = Color(0xFFDCD2EC)

// Semantic Accents
val UrgentRose = Color(0xFFD9386A)
val UrgentRoseContainer = Color(0xFFFFE5EE)
val AmberDeadline = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val MintComplete = Color(0xFF1B8A6B)
val MintContainer = Color(0xFFDFF7EF)

// Dark Mode Palette
val DarkPlumBg = Color(0xFF130E20)
val DarkPlumSurface = Color(0xFF1D1630)
val DarkPlumSurfaceHigh = Color(0xFF282040)
val LavenderLight = Color(0xFFCBB8FF)
val DeepPurpleContainer = Color(0xFF3F2B85)
val PastelPinkDark = Color(0xFFF7B5D2)
val PastelPinkContainerDark = Color(0xFF5F2341)
val LightInk = Color(0xFFF4EFFA)
val MutedLightInk = Color(0xFFC2B7D9)
val DarkOutline = Color(0xFF3E345A)
