package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PastelPinkBlush
import com.example.ui.viewmodel.DayStudyPoint

@Composable
fun StudyProgressRing(
  progress: Float,
  centerValue: String,
  centerLabel: String,
  modifier: Modifier = Modifier,
  size: Dp = 112.dp,
  strokeWidth: Dp = 11.dp,
) {
  val animatedProgress by
    animateFloatAsState(
      targetValue = progress.coerceIn(0f, 1f),
      animationSpec = tween(durationMillis = 700),
      label = "ring_progress",
    )

  val primaryColor = MaterialTheme.colorScheme.primary
  val secondaryColor = MaterialTheme.colorScheme.secondary
  val trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)

  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize().padding(strokeWidth / 2)) {
      val strokePx = strokeWidth.toPx()
      drawArc(
        color = trackColor,
        startAngle = 0f,
        sweepAngle = 360f,
        useCenter = false,
        style = Stroke(width = strokePx, cap = StrokeCap.Round),
      )
      if (animatedProgress > 0f) {
        drawArc(
          brush = Brush.sweepGradient(listOf(primaryColor, secondaryColor, PastelPinkBlush, primaryColor)),
          startAngle = -90f,
          sweepAngle = 360f * animatedProgress,
          useCenter = false,
          style = Stroke(width = strokePx, cap = StrokeCap.Round),
        )
      }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = centerValue,
        style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )
      Text(
        text = centerLabel,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
fun WeeklyStudyBarChart(
  points: List<DayStudyPoint>,
  dailyGoalMinutes: Int,
  modifier: Modifier = Modifier,
) {
  if (points.isEmpty()) return
  val maxMinutes = maxOf(dailyGoalMinutes, points.maxOfOrNull { it.minutes } ?: 60, 60)

  val primaryColor = MaterialTheme.colorScheme.primary
  val tertiaryColor = MaterialTheme.colorScheme.tertiary
  val secondaryColor = MaterialTheme.colorScheme.secondary
  val trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
  val goalLineColor = secondaryColor.copy(alpha = 0.7f)

  Column(modifier = modifier.fillMaxWidth()) {
    Canvas(modifier = Modifier.fillMaxWidth().height(136.dp)) {
      val barCount = points.size
      val slotWidth = size.width / barCount
      val barWidth = (slotWidth * 0.48f).coerceAtMost(32.dp.toPx())
      val chartHeight = size.height

      // Daily goal dashed guide line
      val goalFraction = (dailyGoalMinutes.toFloat() / maxMinutes.toFloat()).coerceIn(0.05f, 1f)
      val goalY = chartHeight * (1f - goalFraction)
      drawLine(
        color = goalLineColor,
        start = Offset(0f, goalY),
        end = Offset(size.width, goalY),
        strokeWidth = 1.5.dp.toPx(),
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f),
      )

      points.forEachIndexed { index, point ->
        val left = slotWidth * index + (slotWidth - barWidth) / 2f
        val corner = CornerRadius(barWidth / 2f, barWidth / 2f)

        // Background pill track
        drawRoundRect(
          color = trackColor,
          topLeft = Offset(left, 0f),
          size = Size(barWidth, chartHeight),
          cornerRadius = corner,
        )

        val ratio = (point.minutes.toFloat() / maxMinutes.toFloat()).coerceIn(0f, 1f)
        val barHeight = (chartHeight * ratio).coerceAtLeast(if (point.minutes > 0) 10.dp.toPx() else 0f)
        if (barHeight > 0f) {
          val brush =
            if (point.isToday) {
              Brush.verticalGradient(listOf(secondaryColor, PastelPinkBlush))
            } else {
              Brush.verticalGradient(listOf(primaryColor, tertiaryColor))
            }
          drawRoundRect(
            brush = brush,
            topLeft = Offset(left, chartHeight - barHeight),
            size = Size(barWidth, barHeight),
            cornerRadius = corner,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
      points.forEach { point ->
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = point.dayShort,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (point.isToday) FontWeight.Bold else FontWeight.Medium,
            color =
              if (point.isToday) MaterialTheme.colorScheme.secondary
              else MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = "${point.minutes}m",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
          )
        }
      }
    }
  }
}
