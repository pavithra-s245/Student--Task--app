package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.TaskEntity
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MintComplete
import com.example.ui.theme.MintContainer
import com.example.ui.theme.UrgentRose
import com.example.ui.theme.UrgentRoseContainer
import com.example.ui.viewmodel.StudentUiState
import com.example.ui.viewmodel.TaskFilter
import com.example.ui.viewmodel.TaskSort

@Composable
fun TasksScreen(
  state: StudentUiState,
  onFilterChange: (TaskFilter) -> Unit,
  onSortChange: (TaskSort) -> Unit,
  onSearchChange: (String) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onEditTask: (TaskEntity) -> Unit,
  onDeleteTask: (TaskEntity) -> Unit,
  onOpenNewTask: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 680.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Header + Sort toggle
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "Tasks & Deadlines",
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = "Assignment deadline tracker · saved on device",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          TextButton(
            onClick = {
              val next =
                if (state.selectedSort == TaskSort.DUE_DATE) TaskSort.PRIORITY
                else TaskSort.DUE_DATE
              onSortChange(next)
            }
          ) {
            Icon(Icons.Outlined.Sort, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(
              text = " ${state.selectedSort.label}",
              style = MaterialTheme.typography.labelMedium,
            )
          }
        }
      }

      // Assignment Deadline Tracker Summary Strip
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          DeadlineSummaryPill(
            label = "Overdue",
            count = state.overdueCount,
            bg = UrgentRoseContainer,
            fg = UrgentRose,
            modifier = Modifier.weight(1f),
          )
          DeadlineSummaryPill(
            label = "Due Soon",
            count = state.dueTodayCount,
            bg = MaterialTheme.colorScheme.secondaryContainer,
            fg = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.weight(1f),
          )
          DeadlineSummaryPill(
            label = "Completed",
            count = state.completedTaskCount,
            bg = MintContainer,
            fg = MintComplete,
            modifier = Modifier.weight(1f),
          )
        }
      }

      // Search Field
      item {
        OutlinedTextField(
          value = state.searchQuery,
          onValueChange = onSearchChange,
          placeholder = { Text("Search tasks or courses (e.g. CS 301)...") },
          leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
          trailingIcon = {
            if (state.searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchChange("") }) {
                Icon(Icons.Outlined.Close, contentDescription = "Clear search")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("task_search_input"),
        )
      }

      // Filter Chips
      item {
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          TaskFilter.entries.forEach { filter ->
            FilterChip(
              selected = state.selectedTaskFilter == filter,
              onClick = { onFilterChange(filter) },
              label = { Text(filter.label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primary,
                  selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                ),
              modifier = Modifier.testTag("filter_${filter.name}"),
            )
          }
        }
      }

      if (state.filteredTasks.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(22.dp),
            colors =
              CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.TaskAlt,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(40.dp),
              )
              Text(
                text = "No matching tasks",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = "Tap the + button to add an assignment, exam, or study task.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              TextButton(onClick = onOpenNewTask) { Text("Create New Task") }
            }
          }
        }
      } else {
        items(state.filteredTasks, key = { it.id }) { task ->
          TaskItemCard(
            task = task,
            onToggleComplete = onToggleTask,
            onEdit = onEditTask,
            onDelete = onDeleteTask,
          )
        }
      }

      item { Spacer(modifier = Modifier.height(76.dp)) }
    }
  }
}

@Composable
private fun DeadlineSummaryPill(
  label: String,
  count: Int,
  bg: Color,
  fg: Color,
  modifier: Modifier = Modifier,
) {
  Surface(modifier = modifier, shape = RoundedCornerShape(16.dp), color = bg) {
    Column(
      modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = count.toString(),
        style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
        fontWeight = FontWeight.Bold,
        color = fg,
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = fg,
      )
    }
  }
}
