package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberDeadline
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MintComplete
import com.example.ui.theme.MintContainer
import com.example.ui.theme.UrgentRose
import com.example.ui.theme.UrgentRoseContainer
import com.example.util.DateTimeUtils

@Composable
fun TaskItemCard(
  task: TaskEntity,
  onToggleComplete: (TaskEntity) -> Unit,
  onEdit: (TaskEntity) -> Unit,
  onDelete: (TaskEntity) -> Unit,
  modifier: Modifier = Modifier,
  showActions: Boolean = true,
) {
  val urgency = DateTimeUtils.getDeadlineUrgency(task.dueDateMillis, task.isCompleted)
  val countdownText = DateTimeUtils.formatCountdown(task.dueDateMillis, task.isCompleted)

  val (badgeBg, badgeFg) =
    when (urgency) {
      DateTimeUtils.DeadlineUrgency.COMPLETED -> MintContainer to MintComplete
      DateTimeUtils.DeadlineUrgency.OVERDUE -> UrgentRoseContainer to UrgentRose
      DateTimeUtils.DeadlineUrgency.DUE_TODAY ->
        MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
      DateTimeUtils.DeadlineUrgency.DUE_SOON -> AmberContainer to AmberDeadline
      DateTimeUtils.DeadlineUrgency.UPCOMING ->
        MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    }

  val cardBg by
    animateColorAsState(
      targetValue =
        if (task.isCompleted) MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.7f)
        else MaterialTheme.colorScheme.surface,
      label = "task_card_bg",
    )

  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .testTag("task_card_${task.id}"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = cardBg),
    border =
      BorderStroke(
        width = 1.dp,
        color =
          if (urgency == DateTimeUtils.DeadlineUrgency.OVERDUE) UrgentRose.copy(alpha = 0.35f)
          else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f),
      ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (task.isCompleted) 0.dp else 1.dp),
    onClick = { onEdit(task) },
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp),
      verticalAlignment = Alignment.Top,
    ) {
      // Tactile 48dp completion button
      Box(
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .clip(CircleShape)
            .clickable { onToggleComplete(task) }
            .testTag("toggle_task_${task.id}"),
        contentAlignment = Alignment.Center,
      ) {
        Surface(
          modifier = Modifier.size(26.dp),
          shape = CircleShape,
          color =
            if (task.isCompleted) MaterialTheme.colorScheme.secondary
            else Color.Transparent,
          border =
            BorderStroke(
              width = 2.dp,
              color =
                if (task.isCompleted) MaterialTheme.colorScheme.secondary
                else MaterialTheme.colorScheme.primary,
            ),
        ) {
          if (task.isCompleted) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "Completed",
                tint = Color.White,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // Course chip + category icon
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Icon(
                  imageVector = categoryIcon(task.category),
                  contentDescription = null,
                  modifier = Modifier.size(13.dp),
                  tint = MaterialTheme.colorScheme.primary,
                )
                Text(
                  text = task.course,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
              }
            }

            PriorityPill(priority = task.priority)
          }

          Surface(shape = RoundedCornerShape(10.dp), color = badgeBg) {
            Text(
              text = countdownText,
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
              fontWeight = FontWeight.SemiBold,
              color = badgeFg,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = task.title,
          style = MaterialTheme.typography.titleMedium,
          color =
            if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.onSurface,
          textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )

        if (task.notes.isNotBlank()) {
          Spacer(modifier = Modifier.height(3.dp))
          Text(
            text = task.notes,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
              imageVector = Icons.Outlined.AccessTime,
              contentDescription = null,
              modifier = Modifier.size(14.dp),
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = "${DateTimeUtils.formatDueDate(task.dueDateMillis)} · ${task.estimatedMinutes}m",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          if (showActions) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { onEdit(task) },
                modifier = Modifier.size(36.dp).testTag("edit_task_${task.id}"),
              ) {
                Icon(
                  imageVector = Icons.Outlined.Edit,
                  contentDescription = "Edit task",
                  modifier = Modifier.size(18.dp),
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
              IconButton(
                onClick = { onDelete(task) },
                modifier = Modifier.size(36.dp).testTag("delete_task_${task.id}"),
              ) {
                Icon(
                  imageVector = Icons.Outlined.DeleteOutline,
                  contentDescription = "Delete task",
                  modifier = Modifier.size(18.dp),
                  tint = MaterialTheme.colorScheme.error,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PriorityPill(priority: TaskPriority) {
  val (bg, fg) =
    when (priority) {
      TaskPriority.HIGH ->
        MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
      TaskPriority.MEDIUM ->
        MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
      TaskPriority.LOW ->
        MaterialTheme.colorScheme.surfaceContainerHigh to MaterialTheme.colorScheme.onSurfaceVariant
    }

  Box(
    modifier =
      Modifier.clip(RoundedCornerShape(6.dp))
        .background(bg)
        .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = priority.label,
      style = MaterialTheme.typography.labelSmall,
      color = fg,
    )
  }
}

fun categoryIcon(category: TaskCategory) =
  when (category) {
    TaskCategory.ASSIGNMENT -> Icons.Outlined.Assignment
    TaskCategory.EXAM -> Icons.Outlined.Quiz
    TaskCategory.PROJECT -> Icons.Outlined.FolderSpecial
    TaskCategory.READING -> Icons.Outlined.AutoStories
    TaskCategory.GENERAL -> Icons.Outlined.TaskAlt
  }
