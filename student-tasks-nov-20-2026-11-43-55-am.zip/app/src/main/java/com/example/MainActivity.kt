package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.StudyBlockEntity
import com.example.data.local.TaskEntity
import com.example.data.local.ThemePreference
import com.example.ui.components.StudyBlockEditorSheet
import com.example.ui.components.TaskEditorSheet
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.WelcomeLoginScreen
import com.example.ui.theme.StudentTaskTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentUiState
import kotlinx.coroutines.launch

private object Routes {
  const val HOME = "home"
  const val TASKS = "tasks"
  const val SCHEDULE = "schedule"
  const val PROFILE = "profile"
}

private data class BottomNavTab(
  val route: String,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

private val TopTabs =
  listOf(
    BottomNavTab(
      route = Routes.HOME,
      labelRes = R.string.nav_home,
      selectedIcon = Icons.Filled.Home,
      unselectedIcon = Icons.Outlined.Home,
      testTag = "nav_home",
    ),
    BottomNavTab(
      route = Routes.TASKS,
      labelRes = R.string.nav_tasks,
      selectedIcon = Icons.Filled.CheckCircle,
      unselectedIcon = Icons.Outlined.CheckCircle,
      testTag = "nav_tasks",
    ),
    BottomNavTab(
      route = Routes.SCHEDULE,
      labelRes = R.string.nav_schedule,
      selectedIcon = Icons.Filled.CalendarMonth,
      unselectedIcon = Icons.Outlined.CalendarMonth,
      testTag = "nav_schedule",
    ),
    BottomNavTab(
      route = Routes.PROFILE,
      labelRes = R.string.nav_profile,
      selectedIcon = Icons.Filled.Person,
      unselectedIcon = Icons.Outlined.Person,
      testTag = "nav_profile",
    ),
  )

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MainViewModel = viewModel()
      val state by viewModel.uiState.collectAsStateWithLifecycle()

      val darkTheme =
        when (state.profile.themePreference) {
          ThemePreference.LIGHT -> false
          ThemePreference.DARK -> true
          ThemePreference.SYSTEM -> isSystemInDarkTheme()
        }

      StudentTaskTheme(darkTheme = darkTheme) {
        if (!state.isInitialized) {
          // Wait briefly for initial DataStore read without flashing login screen
          Scaffold(modifier = Modifier.fillMaxSize()) {}
        } else if (!state.profile.isLoggedIn) {
          WelcomeLoginScreen(
            initialName = state.profile.name,
            initialEmail = state.profile.email,
            initialMajor = state.profile.major,
            initialYear = state.profile.academicYear,
            onSignIn = { name, email, major, year -> viewModel.signIn(name, email, major, year) },
          )
        } else {
          StudentTaskAppShell(state = state, viewModel = viewModel)
        }
      }
    }
  }
}

@Composable
private fun StudentTaskAppShell(state: StudentUiState, viewModel: MainViewModel) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination
  val currentRoute = currentDestination?.route ?: Routes.HOME

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  var showTaskSheet by remember { mutableStateOf(false) }
  var editingTask by remember { mutableStateOf<TaskEntity?>(null) }

  var showBlockSheet by remember { mutableStateOf(false) }
  var editingBlock by remember { mutableStateOf<StudyBlockEntity?>(null) }

  fun navigateToTab(route: String) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  fun deleteTaskWithUndo(task: TaskEntity) {
    viewModel.deleteTask(task)
    scope.launch {
      val res =
        snackbarHostState.showSnackbar(
          message = "Deleted \"${task.title}\"",
          actionLabel = "Undo",
          duration = SnackbarDuration.Short,
        )
      if (res == SnackbarResult.ActionPerformed) {
        viewModel.restoreTask(task)
      }
    }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useNavRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useNavRail) {
        NavigationRail(
          containerColor = MaterialTheme.colorScheme.surface,
        ) {
          TopTabs.forEach { tab ->
            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
            val label = stringResource(tab.labelRes)
            NavigationRailItem(
              selected = selected,
              onClick = { navigateToTab(tab.route) },
              icon = {
                Icon(
                  imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                  contentDescription = label,
                )
              },
              label = { Text(label) },
              colors =
                NavigationRailItemDefaults.colors(
                  selectedIconColor = MaterialTheme.colorScheme.onSecondaryContainer,
                  indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                  selectedTextColor = MaterialTheme.colorScheme.primary,
                ),
              modifier = Modifier.testTag(tab.testTag),
            )
          }
        }
      }

      Scaffold(
        modifier = Modifier.weight(1f).fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
          if (currentRoute == Routes.HOME || currentRoute == Routes.TASKS || currentRoute == Routes.SCHEDULE) {
            FloatingActionButton(
              onClick = {
                if (currentRoute == Routes.SCHEDULE) {
                  editingBlock = null
                  showBlockSheet = true
                } else {
                  editingTask = null
                  showTaskSheet = true
                }
              },
              shape = CircleShape,
              containerColor = MaterialTheme.colorScheme.secondary,
              contentColor = MaterialTheme.colorScheme.onSecondary,
              modifier = Modifier.testTag("main_fab"),
            ) {
              Icon(
                imageVector = Icons.Filled.Add,
                contentDescription =
                  if (currentRoute == Routes.SCHEDULE) "Add study session" else "Add task",
              )
            }
          }
        },
        bottomBar = {
          if (!useNavRail) {
            NavigationBar(
              containerColor = MaterialTheme.colorScheme.surface,
              tonalElevation = 3.dp,
            ) {
              TopTabs.forEach { tab ->
                val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                val label = stringResource(tab.labelRes)
                NavigationBarItem(
                  selected = selected,
                  onClick = { navigateToTab(tab.route) },
                  icon = {
                    Icon(
                      imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      contentDescription = label,
                    )
                  },
                  label = { Text(label) },
                  colors =
                    NavigationBarItemDefaults.colors(
                      selectedIconColor = MaterialTheme.colorScheme.onSecondaryContainer,
                      indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                      selectedTextColor = MaterialTheme.colorScheme.primary,
                    ),
                  modifier = Modifier.testTag(tab.testTag),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        NavHost(
          navController = navController,
          startDestination = Routes.HOME,
          modifier = Modifier.padding(innerPadding),
        ) {
          composable(Routes.HOME) {
            HomeDashboardScreen(
              state = state,
              onToggleTask = { viewModel.toggleTaskComplete(it) },
              onEditTask = {
                editingTask = it
                showTaskSheet = true
              },
              onDeleteTask = { deleteTaskWithUndo(it) },
              onToggleStudyBlock = { viewModel.toggleStudyBlockComplete(it) },
              onLogQuickStudy = { mins ->
                viewModel.logQuickStudyMinutes(mins)
                scope.launch {
                  snackbarHostState.showSnackbar("Logged +${mins}m study focus!")
                }
              },
              onNavigateToTasks = { navigateToTab(Routes.TASKS) },
              onNavigateToSchedule = { navigateToTab(Routes.SCHEDULE) },
              onNavigateToProfile = { navigateToTab(Routes.PROFILE) },
            )
          }

          composable(Routes.TASKS) {
            TasksScreen(
              state = state,
              onFilterChange = { viewModel.setTaskFilter(it) },
              onSortChange = { viewModel.setTaskSort(it) },
              onSearchChange = { viewModel.setSearchQuery(it) },
              onToggleTask = { viewModel.toggleTaskComplete(it) },
              onEditTask = {
                editingTask = it
                showTaskSheet = true
              },
              onDeleteTask = { deleteTaskWithUndo(it) },
              onOpenNewTask = {
                editingTask = null
                showTaskSheet = true
              },
            )
          }

          composable(Routes.SCHEDULE) {
            ScheduleScreen(
              state = state,
              onSelectDay = { viewModel.selectDayOfWeek(it) },
              onAddBlock = {
                editingBlock = null
                showBlockSheet = true
              },
              onEditBlock = {
                editingBlock = it
                showBlockSheet = true
              },
              onToggleBlock = { viewModel.toggleStudyBlockComplete(it) },
              onDeleteBlock = { viewModel.deleteStudyBlock(it) },
            )
          }

          composable(Routes.PROFILE) {
            ProfileScreen(
              state = state,
              onUpdateProfile = { name, email, major, year, goal ->
                viewModel.updateProfile(name, email, major, year, goal)
                scope.launch { snackbarHostState.showSnackbar("Profile updated") }
              },
              onThemeChange = { viewModel.setThemePreference(it) },
              onClearCompleted = {
                viewModel.clearCompletedTasks()
                scope.launch { snackbarHostState.showSnackbar("Cleared completed tasks") }
              },
              onResetSampleData = {
                viewModel.resetSampleData()
                scope.launch { snackbarHostState.showSnackbar("Sample week restored") }
              },
              onSignOut = { viewModel.signOut() },
            )
          }
        }
      }
    }
  }

  if (showTaskSheet) {
    TaskEditorSheet(
      existingTask = editingTask,
      onDismiss = { showTaskSheet = false },
      onSave = { title, course, category, priority, dueMillis, estMinutes, notes ->
        viewModel.saveTask(
          existingId = editingTask?.id ?: 0L,
          title = title,
          course = course,
          category = category,
          priority = priority,
          dueDateMillis = dueMillis,
          estimatedMinutes = estMinutes,
          notes = notes,
          isCompleted = editingTask?.isCompleted ?: false,
        )
      },
      onDelete = { deleteTaskWithUndo(it) },
    )
  }

  if (showBlockSheet) {
    StudyBlockEditorSheet(
      existingBlock = editingBlock,
      initialDayOfWeek = state.selectedDayOfWeek,
      onDismiss = { showBlockSheet = false },
      onSave = { title, course, day, start, end, location, colorTag ->
        viewModel.saveStudyBlock(
          existingId = editingBlock?.id ?: 0L,
          title = title,
          course = course,
          dayOfWeek = day,
          startMinutesFromMidnight = start,
          endMinutesFromMidnight = end,
          location = location,
          colorTag = colorTag,
          isCompleted = editingBlock?.isCompleted ?: false,
        )
      },
      onDelete = { viewModel.deleteStudyBlock(it) },
    )
  }
}
