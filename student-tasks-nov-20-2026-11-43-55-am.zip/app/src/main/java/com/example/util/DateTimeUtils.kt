package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object DateTimeUtils {
  fun currentDayOfWeekMon1Sun7(): Int {
    val cal = Calendar.getInstance()
    return when (cal.get(Calendar.DAY_OF_WEEK)) {
      Calendar.MONDAY -> 1
      Calendar.TUESDAY -> 2
      Calendar.WEDNESDAY -> 3
      Calendar.THURSDAY -> 4
      Calendar.FRIDAY -> 5
      Calendar.SATURDAY -> 6
      Calendar.SUNDAY -> 7
      else -> 1
    }
  }

  fun dayShortLabel(dayOfWeek: Int): String =
    when (dayOfWeek) {
      1 -> "Mon"
      2 -> "Tue"
      3 -> "Wed"
      4 -> "Thu"
      5 -> "Fri"
      6 -> "Sat"
      7 -> "Sun"
      else -> "Mon"
    }

  fun dayFullLabel(dayOfWeek: Int): String =
    when (dayOfWeek) {
      1 -> "Monday"
      2 -> "Tuesday"
      3 -> "Wednesday"
      4 -> "Thursday"
      5 -> "Friday"
      6 -> "Saturday"
      7 -> "Sunday"
      else -> "Monday"
    }

  fun formatMinutesFromMidnight(minutes: Int): String {
    val clamped = minutes.coerceIn(0, 23 * 60 + 59)
    val hour24 = clamped / 60
    val min = clamped % 60
    val amPm = if (hour24 < 12) "AM" else "PM"
    val hour12 =
      when {
        hour24 == 0 -> 12
        hour24 > 12 -> hour24 - 12
        else -> hour24
      }
    return String.format(Locale.US, "%d:%02d %s", hour12, min, amPm)
  }

  fun formatDueDate(millis: Long): String {
    val sdf = SimpleDateFormat("EEE, MMM d · h:mm a", Locale.US)
    return sdf.format(millis)
  }

  fun formatShortDate(millis: Long): String {
    val sdf = SimpleDateFormat("MMM d", Locale.US)
    return sdf.format(millis)
  }

  fun formatMinutesDuration(minutes: Int): String {
    val hrs = minutes / 60
    val mins = minutes % 60
    return when {
      hrs > 0 && mins > 0 -> "${hrs}h ${mins}m"
      hrs > 0 -> "${hrs}h"
      else -> "${mins}m"
    }
  }

  enum class DeadlineUrgency {
    COMPLETED,
    OVERDUE,
    DUE_TODAY,
    DUE_SOON,
    UPCOMING,
  }

  fun getDeadlineUrgency(dueDateMillis: Long, isCompleted: Boolean): DeadlineUrgency {
    if (isCompleted) return DeadlineUrgency.COMPLETED
    val now = System.currentTimeMillis()
    val endOfToday =
      Calendar.getInstance()
        .apply {
          set(Calendar.HOUR_OF_DAY, 23)
          set(Calendar.MINUTE, 59)
          set(Calendar.SECOND, 59)
          set(Calendar.MILLISECOND, 999)
        }
        .timeInMillis
    val threeDaysOut = endOfToday + 3L * 86_400_000L

    return when {
      dueDateMillis < now -> DeadlineUrgency.OVERDUE
      dueDateMillis <= endOfToday -> DeadlineUrgency.DUE_TODAY
      dueDateMillis <= threeDaysOut -> DeadlineUrgency.DUE_SOON
      else -> DeadlineUrgency.UPCOMING
    }
  }

  fun formatCountdown(dueDateMillis: Long, isCompleted: Boolean): String {
    if (isCompleted) return "Done"
    val diff = dueDateMillis - System.currentTimeMillis()
    if (diff < 0) {
      val overdueHours = (-diff / 3_600_000L).coerceAtLeast(1)
      return if (overdueHours < 24) "Overdue ${overdueHours}h" else "Overdue ${overdueHours / 24}d"
    }
    val totalHours = diff / 3_600_000L
    val days = totalHours / 24
    val hours = totalHours % 24
    return when {
      totalHours < 1 -> "Due < 1h"
      days == 0L -> "Due in ${totalHours}h"
      days == 1L -> "Tomorrow"
      else -> "${days}d ${hours}h left"
    }
  }

  fun greetingForTimeOfDay(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
      hour < 12 -> "Good morning"
      hour < 17 -> "Good afternoon"
      else -> "Good evening"
    }
  }
}
